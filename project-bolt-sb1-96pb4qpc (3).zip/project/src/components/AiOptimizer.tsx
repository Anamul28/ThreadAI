import React, { useState } from 'react';
import { Sparkles, RefreshCw, Check, ThumbsUp, ThumbsDown, BarChart3 } from 'lucide-react';
import { optimizeReply, OptimizationRequest, OptimizationResponse, analyzeContent } from '../services/aiService';
import TextareaAutosize from 'react-textarea-autosize';

interface AiOptimizerProps {
  initialText: string;
  onSelectOptimized: (text: string) => void;
}

const AiOptimizer: React.FC<AiOptimizerProps> = ({ initialText, onSelectOptimized }) => {
  const [text, setText] = useState(initialText);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResponse | null>(null);
  const [selectedPlatform, setSelectedPlatform] = useState<'twitter' | 'linkedin' | 'facebook' | 'instagram'>('twitter');
  const [selectedTone, setSelectedTone] = useState<'professional' | 'casual' | 'friendly' | 'authoritative'>('professional');
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [contentAnalysis, setContentAnalysis] = useState<ReturnType<typeof analyzeContent> | null>(null);

  const handleOptimize = async () => {
    if (!text.trim()) return;
    
    setIsOptimizing(true);
    
    try {
      const request: OptimizationRequest = {
        originalText: text,
        targetPlatform: selectedPlatform,
        tone: selectedTone,
        maxLength: selectedPlatform === 'twitter' ? 280 : 1000
      };
      
      const result = await optimizeReply(request);
      setOptimizationResult(result);
      
      // Also run content analysis
      setContentAnalysis(analyzeContent(text));
    } catch (error) {
      console.error('Error optimizing reply:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleSelectSuggestion = (suggestion: string) => {
    setText(suggestion);
    onSelectOptimized(suggestion);
  };

  const handleUseOptimized = () => {
    if (optimizationResult) {
      setText(optimizationResult.optimizedText);
      onSelectOptimized(optimizationResult.optimizedText);
    }
  };

  const toggleAnalysis = () => {
    if (!showAnalysis && !contentAnalysis) {
      setContentAnalysis(analyzeContent(text));
    }
    setShowAnalysis(!showAnalysis);
  };

  return (
    <div className="border border-purple-200 rounded-xl p-5 bg-purple-50">
      <h3 className="text-lg font-semibold text-purple-800 mb-4 flex items-center">
        <Sparkles className="h-5 w-5 mr-2 text-purple-600" />
        AI Reply Optimizer
      </h3>
      
      <div className="mb-4 grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Platform</label>
          <select
            value={selectedPlatform}
            onChange={(e) => setSelectedPlatform(e.target.value as any)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
          >
            <option value="twitter">Twitter</option>
            <option value="linkedin">LinkedIn</option>
            <option value="facebook">Facebook</option>
            <option value="instagram">Instagram</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Tone</label>
          <select
            value={selectedTone}
            onChange={(e) => setSelectedTone(e.target.value as any)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
          >
            <option value="professional">Professional</option>
            <option value="casual">Casual</option>
            <option value="friendly">Friendly</option>
            <option value="authoritative">Authoritative</option>
          </select>
        </div>
      </div>
      
      <div className="mb-4">
        <TextareaAutosize
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
          placeholder="Enter your reply text to optimize..."
          minRows={3}
        />
        <div className="flex justify-between mt-1">
          <span className="text-xs text-gray-500">
            {text.length} characters
            {selectedPlatform === 'twitter' && (
              <span className={text.length > 280 ? 'text-red-500' : ''}>
                {' '}/{' '}280
              </span>
            )}
          </span>
          <button
            onClick={toggleAnalysis}
            className="text-xs text-purple-600 hover:text-purple-800 flex items-center"
          >
            <BarChart3 className="h-3 w-3 mr-1" />
            {showAnalysis ? 'Hide Analysis' : 'Show Analysis'}
          </button>
        </div>
      </div>
      
      {showAnalysis && contentAnalysis && (
        <div className="mb-4 p-3 bg-white rounded-lg border border-purple-100">
          <h4 className="text-sm font-medium text-purple-800 mb-2">Content Analysis</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center">
              <span className="text-gray-600">Word count:</span>
              <span className="ml-1 font-medium">{contentAnalysis.wordCount}</span>
            </div>
            <div className="flex items-center">
              <span className="text-gray-600">Read time:</span>
              <span className="ml-1 font-medium">{contentAnalysis.readTime} min</span>
            </div>
            <div className="flex items-center">
              <span className="text-gray-600">Sentiment:</span>
              <span className={`ml-1 font-medium ${
                contentAnalysis.sentiment === 'positive' ? 'text-green-600' : 
                contentAnalysis.sentiment === 'negative' ? 'text-red-600' : 'text-gray-600'
              }`}>
                {contentAnalysis.sentiment}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-gray-600">Keywords:</span>
              <span className="ml-1 font-medium">{contentAnalysis.keywords.join(', ')}</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex justify-center">
        <button
          onClick={handleOptimize}
          disabled={isOptimizing || !text.trim()}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isOptimizing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Optimizing...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Optimize Reply
            </>
          )}
        </button>
      </div>
      
      {optimizationResult && (
        <div className="mt-6">
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Optimized Version</h4>
            <div className="p-3 bg-white border border-green-200 rounded-lg text-gray-800">
              {optimizationResult.optimizedText}
            </div>
            <div className="flex justify-end mt-2">
              <button
                onClick={handleUseOptimized}
                className="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-lg text-green-700 bg-green-50 hover:bg-green-100 transition-colors"
              >
                <Check className="h-3.5 w-3.5 mr-1.5" />
                Use This Version
              </button>
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Alternative Suggestions</h4>
            <div className="space-y-3">
              {optimizationResult.suggestions.map((suggestion, index) => (
                <div key={index} className="p-3 bg-white border border-gray-200 rounded-lg text-gray-800">
                  {suggestion}
                  <div className="flex justify-between mt-2">
                    <div className="flex space-x-2">
                      <button className="text-gray-400 hover:text-green-600 p-1">
                        <ThumbsUp className="h-4 w-4" />
                      </button>
                      <button className="text-gray-400 hover:text-red-600 p-1">
                        <ThumbsDown className="h-4 w-4" />
                      </button>
                    </div>
                    <button
                      onClick={() => handleSelectSuggestion(suggestion)}
                      className="inline-flex items-center px-3 py-1 text-xs font-medium rounded-lg text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors"
                    >
                      Use This
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-4 bg-purple-100 rounded-lg p-3">
            <h4 className="text-sm font-medium text-purple-800 mb-2">Optimization Metrics</h4>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(optimizationResult.metrics).map(([key, value]) => (
                <div key={key} className="bg-white rounded-lg p-2 text-center">
                  <div className="text-xs text-gray-500 capitalize">{key}</div>
                  <div className="text-lg font-semibold text-purple-700">{value}%</div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div 
                      className="bg-purple-600 h-1.5 rounded-full" 
                      style={{ width: `${value}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AiOptimizer;