import React, { useState, useEffect } from 'react';
import { Menu, X, Code } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-200 ${
      isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Code className={`h-8 w-8 ${isScrolled ? 'text-blue-600' : 'text-white'}`} />
              <span className={`ml-2 font-bold text-xl ${isScrolled ? 'text-blue-600' : 'text-white'}`}>
                ThreadAI
              </span>
            </div>
            <div className="hidden sm:ml-10 sm:flex sm:space-x-8">
              <a href="#" className={`inline-flex items-center px-1 pt-1 border-b-2 border-blue-500 text-sm font-medium ${
                isScrolled ? 'text-gray-900' : 'text-white'
              }`}>
                Home
              </a>
              <a href="#features" className={`inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium ${
                isScrolled ? 'text-gray-500 hover:text-gray-700 hover:border-gray-300' : 'text-white hover:border-white'
              }`}>
                Features
              </a>
              <a href="#pricing" className={`inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium ${
                isScrolled ? 'text-gray-500 hover:text-gray-700 hover:border-gray-300' : 'text-white hover:border-white'
              }`}>
                Pricing
              </a>
              <a href="#testimonials" className={`inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium ${
                isScrolled ? 'text-gray-500 hover:text-gray-700 hover:border-gray-300' : 'text-white hover:border-white'
              }`}>
                Testimonials
              </a>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <button className={`px-4 py-2 rounded-md text-sm font-medium ${
              isScrolled 
                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                : 'bg-white hover:bg-blue-50 text-blue-600'
            }`}>
              Get Started
            </button>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`inline-flex items-center justify-center p-2 rounded-md ${
                isScrolled 
                  ? 'text-gray-400 hover:text-gray-500 hover:bg-gray-100' 
                  : 'text-white hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="sm:hidden bg-white shadow-lg">
          <div className="pt-2 pb-3 space-y-1">
            <a href="#" className="bg-blue-50 border-blue-500 text-blue-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
              Home
            </a>
            <a href="#features" className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
              Features
            </a>
            <a href="#pricing" className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
              Pricing
            </a>
            <a href="#testimonials" className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
              Testimonials
            </a>
            <div className="mt-4 pl-3 pr-4">
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                Get Started
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;