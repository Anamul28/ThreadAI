import React, { useState } from 'react';
import { X } from 'lucide-react';
import TextareaAutosize from 'react-textarea-autosize';

interface Reply {
  id: string;
  text: string;
  inReplyTo: string;
  tags?: string[];
  createdAt: string;
}

interface EditReplyModalProps {
  reply: Reply;
  onSave: (updatedReply: Reply) => void;
  onCancel: () => void;
}

const EditReplyModal: React.FC<EditReplyModalProps> = ({ reply, onSave, onCancel }) => {
  const [text, setText] = useState(reply.text);
  const [inReplyTo, setInReplyTo] = useState(reply.inReplyTo);
  const [tags, setTags] = useState<string[]>(reply.tags || []);
  const [currentTag, setCurrentTag] = useState('');

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && currentTag.trim()) {
      e.preventDefault();
      if (!tags.includes(currentTag.trim())) {
        setTags([...tags, currentTag.trim()]);
      }
      setCurrentTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleSave = () => {
    if (text.trim()) {
      onSave({
        ...reply,
        text,
        inReplyTo,
        tags,
      });
    }
  };

  const characterCount = text.length;
  const isOverLimit = characterCount > 280;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-8 max-w-lg w-full">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Edit Reply</h3>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-500 p-1.5 rounded-full hover:bg-gray-100">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="mb-5">
          <label htmlFor="edit-in-reply-to" className="block text-sm font-medium text-gray-700 mb-1">
            In Reply To
          </label>
          <input
            type="text"
            id="edit-in-reply-to"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
            value={inReplyTo}
            onChange={(e) => setInReplyTo(e.target.value)}
          />
        </div>
        
        <div className="mb-5">
          <label htmlFor="edit-reply-text" className="block text-sm font-medium text-gray-700 mb-1">
            Reply Text
          </label>
          <TextareaAutosize
            id="edit-reply-text"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
            minRows={4}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className={`text-sm mt-1 ${isOverLimit ? 'text-red-500' : 'text-gray-500'}`}>
            {characterCount}/280 characters
          </div>
        </div>
        
        <div className="mb-5">
          <label htmlFor="edit-tags" className="block text-sm font-medium text-gray-700 mb-1">
            Tags
          </label>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            {tags.map(tag => (
              <span key={tag} className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                #{tag}
                <button onClick={() => removeTag(tag)} className="ml-1 text-blue-500 hover:text-blue-700">
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
          <input
            type="text"
            id="edit-tags"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
            placeholder="Add tags (press Enter to add)"
            value={currentTag}
            onChange={(e) => setCurrentTag(e.target.value)}
            onKeyDown={handleAddTag}
          />
        </div>
        
        <div className="flex justify-end space-x-3">
          <button
            onClick={onCancel}
            className="px-5 py-2.5 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2.5 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            disabled={isOverLimit || !text.trim()}
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditReplyModal;