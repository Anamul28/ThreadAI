import { supabase } from '../lib/supabase';

// Types for AI optimization
export interface OptimizationRequest {
  originalText: string;
  targetPlatform: 'twitter' | 'linkedin' | 'facebook' | 'instagram';
  tone?: 'professional' | 'casual' | 'friendly' | 'authoritative';
  maxLength?: number;
}

export interface OptimizationResponse {
  optimizedText: string;
  suggestions: string[];
  metrics: {
    readability: number;
    engagement: number;
    clarity: number;
  };
}

// Mock AI optimization function
// In a real app, this would call an actual AI service API
export async function optimizeReply(request: OptimizationRequest): Promise<OptimizationResponse> {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const { originalText, targetPlatform, tone = 'professional', maxLength = 280 } = request;
  
  // Simple text optimization logic
  let optimizedText = originalText;
  
  // Truncate if too long
  if (optimizedText.length > maxLength) {
    optimizedText = optimizedText.substring(0, maxLength - 3) + '...';
  }
  
  // Add platform-specific enhancements
  if (targetPlatform === 'twitter') {
    // Add hashtags for Twitter if none exist
    if (!optimizedText.includes('#')) {
      const possibleHashtags = ['#engagement', '#socialmedia', '#content', '#digital', '#marketing'];
      const selectedHashtags = possibleHashtags.slice(0, 2);
      optimizedText = optimizedText + ' ' + selectedHashtags.join(' ');
    }
  }
  
  // Generate alternative suggestions based on tone
  const suggestions = generateSuggestions(originalText, tone);
  
  // Calculate mock metrics
  const metrics = {
    readability: Math.min(Math.round(Math.random() * 40 + 60), 100), // 60-100
    engagement: Math.min(Math.round(Math.random() * 40 + 60), 100),  // 60-100
    clarity: Math.min(Math.round(Math.random() * 40 + 60), 100)      // 60-100
  };
  
  return {
    optimizedText,
    suggestions,
    metrics
  };
}

// Generate alternative suggestions based on tone
function generateSuggestions(text: string, tone: string): string[] {
  const suggestions: string[] = [];
  
  // Professional tone suggestions
  if (tone === 'professional') {
    suggestions.push(
      text.replace(/I think/gi, 'Research indicates').replace(/good/gi, 'excellent'),
      text.replace(/we can/gi, 'we have the capability to').replace(/problem/gi, 'challenge')
    );
  }
  
  // Casual tone suggestions
  else if (tone === 'casual') {
    suggestions.push(
      text.replace(/Additionally/gi, 'Plus').replace(/however/gi, 'but'),
      text.replace(/therefore/gi, 'so').replace(/utilize/gi, 'use')
    );
  }
  
  // Friendly tone suggestions
  else if (tone === 'friendly') {
    suggestions.push(
      text.replace(/Hello/gi, 'Hey there').replace(/Thank you/gi, 'Thanks so much'),
      text + ' Looking forward to hearing your thoughts!'
    );
  }
  
  // Authoritative tone suggestions
  else if (tone === 'authoritative') {
    suggestions.push(
      text.replace(/I believe/gi, 'It is clear that').replace(/might/gi, 'will'),
      text.replace(/could/gi, 'must').replace(/perhaps/gi, 'certainly')
    );
  }
  
  // If suggestions are identical to original or to each other, provide generic alternatives
  const uniqueSuggestions = [
    "Thank you for sharing your perspective. I appreciate the thoughtful analysis.",
    "This is a fascinating insight! I'd love to explore this topic further.",
    "I see your point, though I respectfully have a different view on this matter.",
    "What an interesting approach to this problem. I hadn't considered that angle before.",
    "I completely agree with your assessment. The evidence makes a compelling case."
  ];
  
  // Fill remaining slots with unique suggestions
  while (suggestions.length < 3) {
    const randomIndex = Math.floor(Math.random() * uniqueSuggestions.length);
    const suggestion = uniqueSuggestions[randomIndex];
    
    if (!suggestions.includes(suggestion) && suggestion !== text) {
      suggestions.push(suggestion);
    }
  }
  
  return suggestions.slice(0, 3); // Return at most 3 suggestions
}

// Function to auto-save draft replies
export async function autoSaveDraft(userId: string, draftData: any): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('drafts')
      .upsert({
        user_id: userId,
        content: draftData,
        updated_at: new Date().toISOString()
      });
      
    return !error;
  } catch (e) {
    console.error('Error auto-saving draft:', e);
    return false;
  }
}

// Function to retrieve saved drafts
export async function getSavedDrafts(userId: string): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('drafts')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });
      
    if (error) throw error;
    return data || [];
  } catch (e) {
    console.error('Error retrieving drafts:', e);
    return [];
  }
}

// Function to analyze reply content
export function analyzeContent(text: string): {
  wordCount: number;
  readTime: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  keywords: string[];
} {
  // Count words
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  
  // Estimate read time (average reading speed: 200 words per minute)
  const readTime = Math.max(Math.ceil(wordCount / 200), 1);
  
  // Simple sentiment analysis
  const positiveWords = ['good', 'great', 'excellent', 'amazing', 'love', 'best', 'happy', 'thank', 'thanks', 'appreciate'];
  const negativeWords = ['bad', 'poor', 'terrible', 'awful', 'hate', 'worst', 'sad', 'sorry', 'problem', 'issue'];
  
  const words = text.toLowerCase().match(/\b(\w+)\b/g) || [];
  let positiveCount = 0;
  let negativeCount = 0;
  
  words.forEach(word => {
    if (positiveWords.includes(word)) positiveCount++;
    if (negativeWords.includes(word)) negativeCount++;
  });
  
  let sentiment: 'positive' | 'neutral' | 'negative' = 'neutral';
  if (positiveCount > negativeCount) sentiment = 'positive';
  else if (negativeCount > positiveCount) sentiment = 'negative';
  
  // Extract potential keywords (simple implementation)
  const stopWords = ['the', 'and', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were'];
  const keywords = words
    .filter(word => word.length > 3 && !stopWords.includes(word))
    .reduce((acc: {[key: string]: number}, word) => {
      acc[word] = (acc[word] || 0) + 1;
      return acc;
    }, {});
  
  // Get top 5 keywords
  const topKeywords = Object.entries(keywords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([word]) => word);
  
  return {
    wordCount,
    readTime,
    sentiment,
    keywords: topKeywords
  };
}