import React from 'react';
import TwitterReplyManager from '../components/TwitterReplyManager';

const TwitterReplyPage: React.FC = () => {
  return <TwitterReplyManager />;
};

export default TwitterReplyPage;