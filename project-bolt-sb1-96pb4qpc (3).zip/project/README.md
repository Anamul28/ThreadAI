# ThreadAI - Social Media Reply Management Tool

ThreadAI is a powerful tool designed to help you save, organize, and schedule your best social media replies. Built with React, TypeScript, Tailwind CSS, and Supabase, this application provides a seamless experience for managing your social media content.

![ThreadAI Screenshot](https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80)

## Features

- **Save Thoughtful Replies**: Store your well-crafted responses for future use
- **Tag and Categorize**: Organize replies with custom tags for easy filtering
- **Queue as Tweets**: Convert replies into standalone tweets for later posting
- **Schedule Posts**: Set specific dates and times for your queued tweets
- **Export/Import Data**: Backup and restore your saved replies and queue
- **Auto-save Drafts**: Never lose your work with automatic draft saving
- **User Authentication**: Secure user accounts with email/password authentication
- **Real-time Updates**: Changes sync instantly across devices

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Supabase account

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/threadai.git
cd threadai
```

2. Install dependencies:
```bash
npm install
# or
yarn
```

3. Set up Supabase:
   - Create a new Supabase project
   - Run the SQL migration in `supabase/migrations/create_tables.sql`
   - Copy your Supabase URL and anon key
   - Create a `.env` file based on `.env.example` and add your Supabase credentials

4. Start the development server:
```bash
npm run dev
# or
yarn dev
```

5. Open your browser and navigate to `http://localhost:5173`

## Usage Guide

### Authentication

1. Sign up with your email and password
2. Verify your email address (if required)
3. Sign in to access your saved replies and queue

### Composing and Saving Replies

1. Enter the URL or username you're replying to in the "In Reply To" field
2. Craft your reply in the text area (280 character limit)
3. Add relevant tags to categorize your reply
4. Click "Save Reply" to store it for future use

### Managing Saved Replies

- Use the search bar to find specific replies
- Filter replies by tags
- Sort replies by newest or oldest
- Edit, delete, or queue replies as needed

### Working with the Tweet Queue

- Add saved replies to your tweet queue
- Reorder tweets in the queue using the up/down arrows
- Schedule tweets for specific dates and times
- Post tweets immediately or in batch

### Data Management

- Export your data for backup using the settings menu
- Import previously exported data to restore your replies and queue

## Deployment

To build the application for production:

```bash
npm run build
# or
yarn build
```

The built files will be in the `dist` directory, ready to be deployed to your hosting provider of choice.

## Technologies Used

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Supabase (Authentication & Database)
- date-fns
- react-datepicker
- react-textarea-autosize
- Lucide React icons

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Inspired by the need for better social media content management
- UI design influenced by modern web applications