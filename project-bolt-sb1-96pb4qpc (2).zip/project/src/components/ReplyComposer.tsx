import React, { useState, useContext, useEffect } from 'react';
import { Save, Send, Sparkles, X } from 'lucide-react';
import TextareaAutosize from 'react-textarea-autosize';
import { ReplyContext } from '../context/ReplyContext';
import { v4 as uuidv4 } from 'uuid';
import AiOptimizer from './AiOptimizer';

const ReplyComposer = () => {
  const [replyText, setReplyText] = useState('');
  const [inReplyTo, setInReplyTo] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');
  const [isAutoSaveEnabled, setIsAutoSaveEnabled] = useState(true);
  const [draftKey, setDraftKey] = useState('');
  const [showAiOptimizer, setShowAiOptimizer] = useState(false);
  const { addSavedReply } = useContext(ReplyContext);

  // Load draft on component mount
  useEffect(() => {
    const savedDraft = localStorage.getItem('replyDraft');
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        setReplyText(draft.text || '');
        setInReplyTo(draft.inReplyTo || '');
        setTags(draft.tags || []);
        setDraftKey(draft.draftKey || uuidv4());
      } catch (e) {
        console.error('Error loading draft:', e);
        setDraftKey(uuidv4());
      }
    } else {
      setDraftKey(uuidv4());
    }
  }, []);

  // Auto-save draft when text changes
  useEffect(() => {
    if (isAutoSaveEnabled && (replyText || inReplyTo || tags.length > 0)) {
      const draftData = {
        text: replyText,
        inReplyTo,
        tags,
        draftKey,
        lastSaved: new Date().toISOString()
      };
      localStorage.setItem('replyDraft', JSON.stringify(draftData));
    }
  }, [replyText, inReplyTo, tags, draftKey, isAutoSaveEnabled]);

  const handleSaveReply = () => {
    if (replyText.trim()) {
      const newReply = {
        id: uuidv4(),
        text: replyText,
        inReplyTo: inReplyTo || 'N/A',
        tags: [...tags],
        createdAt: new Date().toISOString(),
      };
      
      addSavedReply(newReply);
      
      // Clear form and draft after saving
      setReplyText('');
      setInReplyTo('');
      setTags([]);
      localStorage.removeItem('replyDraft');
      setDraftKey(uuidv4());
      setShowAiOptimizer(false);
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && currentTag.trim()) {
      e.preventDefault();
      if (!tags.includes(currentTag.trim())) {
        setTags([...tags, currentTag.trim()]);
      }
      setCurrentTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const toggleAiOptimizer = () => {
    setShowAiOptimizer(!showAiOptimizer);
  };

  const handleOptimizedText = (optimizedText: string) => {
    setReplyText(optimizedText);
  };

  const characterCount = replyText.length;
  const isOverLimit = characterCount > 280;

  return (
    <div className="border border-gray-200 rounded-xl p-6 bg-white shadow-sm">
      <div className="mb-5">
        <label htmlFor="in-reply-to" className="block text-sm font-medium text-gray-700 mb-1">
          In Reply To (URL or @username)
        </label>
        <input
          type="text"
          id="in-reply-to"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          placeholder="https://twitter.com/username/status/123456789 or @username"
          value={inReplyTo}
          onChange={(e) => setInReplyTo(e.target.value)}
        />
      </div>
      
      <div className="mb-5">
        <label htmlFor="reply-text" className="block text-sm font-medium text-gray-700 mb-1">
          Your Reply
        </label>
        <div className="relative">
          <TextareaAutosize
            id="reply-text"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
            placeholder="Type your thoughtful reply here..."
            minRows={4}
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
          />
          <button 
            onClick={toggleAiOptimizer}
            className="absolute right-3 bottom-3 p-2 rounded-md bg-purple-100 text-purple-600 hover:bg-purple-200 transition-colors"
            title={showAiOptimizer ? "Hide AI Optimizer" : "Show AI Optimizer"}
          >
            <Sparkles className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      {showAiOptimizer && (
        <div className="mb-5">
          <AiOptimizer 
            initialText={replyText} 
            onSelectOptimized={handleOptimizedText} 
          />
        </div>
      )}
      
      <div className="mb-5">
        <label htmlFor="tags" className="block text-sm font-medium text-gray-700 mb-1">
          Tags (press Enter to add)
        </label>
        <div className="flex flex-wrap items-center gap-2 mb-2">
          {tags.map(tag => (
            <span key={tag} className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              #{tag}
              <button onClick={() => removeTag(tag)} className="ml-1 text-blue-500 hover:text-blue-700">
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
        <input
          type="text"
          id="tags"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          placeholder="Add tags to categorize your reply (e.g., tech, opinion)"
          value={currentTag}
          onChange={(e) => setCurrentTag(e.target.value)}
          onKeyDown={handleAddTag}
        />
      </div>
      
      <div className="flex items-center mb-5">
        <input
          id="auto-save"
          type="checkbox"
          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          checked={isAutoSaveEnabled}
          onChange={() => setIsAutoSaveEnabled(!isAutoSaveEnabled)}
        />
        <label htmlFor="auto-save" className="ml-2 block text-sm text-gray-700">
          Auto-save draft while typing
        </label>
        {isAutoSaveEnabled && (
          <span className="ml-auto text-xs text-gray-500">
            Draft auto-saved
          </span>
        )}
      </div>
      
      <div className="flex items-center justify-between">
        <div className={`text-sm ${isOverLimit ? 'text-red-500' : 'text-gray-500'}`}>
          {characterCount}/280 characters
        </div>
        
        <div className="flex space-x-3">
          <button
            className="inline-flex items-center px-5 py-2.5 border border-gray-300 shadow-sm text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            onClick={handleSaveReply}
            disabled={isOverLimit || !replyText.trim()}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Reply
          </button>
          
          <button
            className="inline-flex items-center px-5 py-2.5 border border-transparent text-sm font-medium rounded-lg shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            disabled={isOverLimit || !replyText.trim()}
          >
            <Send className="h-4 w-4 mr-2" />
            Reply Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReplyComposer;