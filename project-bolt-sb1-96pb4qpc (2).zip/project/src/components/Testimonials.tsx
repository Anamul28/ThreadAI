import React from 'react';

const testimonials = [
  {
    content: "Reply Optimizer has completely transformed how I manage my social media presence. I can now save my best replies and repurpose them as standalone tweets with just a few clicks.",
    author: "Sarah Johnson",
    role: "Social Media Manager",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    content: "As a content creator, I need tools that save me time. Reply Optimizer lets me schedule my best content for optimal posting times, increasing my engagement significantly.",
    author: "Michael Chen",
    role: "Content Creator",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    content: "The tagging system is brilliant! I can categorize all my replies and find exactly what I need when responding to similar questions or comments. A real time-saver.",
    author: "Emma Rodriguez",
    role: "Digital Marketing Specialist",
    image: "https://images.unsplash.com/photo-1509783236416-c9ad59bae472?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
];

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-16 bg-gray-50 overflow-hidden">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative">
          <div className="text-center">
            <h2 className="text-base font-semibold text-blue-600 tracking-wide uppercase">Testimonials</h2>
            <p className="mt-3 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Loved by social media professionals
            </p>
          </div>
          <div className="mt-12 max-w-lg mx-auto grid gap-8 lg:grid-cols-3 lg:max-w-none">
            {testimonials.map((testimonial) => (
              <div key={testimonial.author} className="flex flex-col rounded-xl shadow-lg overflow-hidden transform transition-all hover:scale-[1.02]">
                <div className="flex-1 bg-white p-8 flex flex-col justify-between">
                  <div className="flex-1">
                    <p className="text-lg font-medium text-gray-900">
                      <span className="text-blue-500 text-2xl">"</span>{testimonial.content}<span className="text-blue-500 text-2xl">"</span>
                    </p>
                  </div>
                  <div className="mt-6 flex items-center">
                    <div className="flex-shrink-0">
                      <img className="h-12 w-12 rounded-full" src={testimonial.image} alt={testimonial.author} />
                    </div>
                    <div className="ml-3">
                      <p className="text-base font-medium text-gray-900">{testimonial.author}</p>
                      <p className="text-sm text-gray-500">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;