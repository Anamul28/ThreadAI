import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Send, Save, List, Edit, Trash2, Search } from 'lucide-react';

function TwitterReplyManager() {
  const [replies, setReplies] = useState<any[]>([]);
  const [newReply, setNewReply] = useState({
    content: '',
    scheduledFor: '',
    inReplyTo: '',
    tags: []
  });
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [selectedTab, setSelectedTab] = useState('compose');
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState<{message: string, type: string} | null>(null);

  // Simulated Twitter authentication
  const authorizeTwitter = () => {
    setIsLoading(true);
    // In a real app, this would redirect to Twitter OAuth
    setTimeout(() => {
      setIsAuthorized(true);
      setIsLoading(false);
      showNotification("Successfully connected to Twitter", "success");
    }, 1500);
  };

  // Add a new reply to the queue
  const saveReply = () => {
    if (!newReply.content.trim()) {
      showNotification("Reply content cannot be empty", "error");
      return;
    }

    const replyToAdd = {
      ...newReply,
      id: Date.now(),
      createdAt: new Date().toISOString(),
      status: 'queued'
    };

    setReplies([...replies, replyToAdd]);
    setNewReply({
      content: '',
      scheduledFor: '',
      inReplyTo: '',
      tags: []
    });

    showNotification("Reply saved to queue", "success");
  };

  // Send reply immediately or schedule it
  const sendReply = (id: number) => {
    setIsLoading(true);

    // Update status of the reply
    const updatedReplies = replies.map(reply =>
      reply.id === id ? {...reply, status: 'sent'} : reply
    );

    // In a real app, this would use the Twitter API
    setTimeout(() => {
      setReplies(updatedReplies);
      setIsLoading(false);
      showNotification("Reply sent successfully", "success");
    }, 1500);
  };

  // Delete reply from queue
  const deleteReply = (id: number) => {
    setReplies(replies.filter(reply => reply.id !== id));
    showNotification("Reply removed from queue", "info");
  };

  // Show notification
  const showNotification = (message: string, type: string) => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  // Filter replies based on search term
  const filteredReplies = replies.filter(reply =>
    reply.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    reply.inReplyTo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 p-4 border-b border-gray-700">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold flex items-center">
            <Send className="mr-2" size={20} />
            Twitter Reply Queue Manager
          </h1>

          {!isAuthorized ? (
            <button
              onClick={authorizeTwitter}
              className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-md flex items-center"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Connect Twitter"}
            </button>
          ) : (
            <div className="flex items-center space-x-2 bg-gray-700 px-3 py-2 rounded-md">
              <div className="h-6 w-6 bg-blue-400 rounded-full"></div>
              <span>@YourTwitterHandle</span>
            </div>
          )}
        </div>
      </header>

      {/* Notification */}
      {notification && (
        <div className={`fixed top-4 right-4 p-4 rounded-md shadow-lg ${
          notification.type === 'success' ? 'bg-green-500' :
          notification.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        }`}>
          {notification.message}
        </div>
      )}

      {/* Main Content */}
      <main className="container mx-auto p-6">
        {!isAuthorized ? (
          <div className="text-center py-12">
            <h2 className="text-2xl mb-4">Welcome to Twitter Reply Queue Manager</h2>
            <p className="text-gray-400 mb-8 max-w-lg mx-auto">
              This tool helps you save elaborate replies and schedule them for later.
              Connect your Twitter account to get started.
            </p>
            <button
              onClick={authorizeTwitter}
              className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded-md"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Connect Twitter Account"}
            </button>
          </div>
        ) : (
          <>
            {/* Tab Navigation */}
            <div className="flex mb-6 border-b border-gray-700">
              <button
                className={`py-3 px-4 ${selectedTab === 'compose' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400'}`}
                onClick={() => setSelectedTab('compose')}
              >
                <Edit className="inline mr-2" size={18} />
                Compose
              </button>
              <button
                className={`py-3 px-4 ${selectedTab === 'queue' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400'}`}
                onClick={() => setSelectedTab('queue')}
              >
                <List className="inline mr-2" size={18} />
                Queue
                {replies.length > 0 && <span className="ml-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">{replies.length}</span>}
              </button>
            </div>

            {/* Compose Reply */}
            {selectedTab === 'compose' && (
              <div className="bg-gray-800 p-6 rounded-xl">
                <h2 className="text-xl font-semibold mb-4">Compose Reply</h2>

                <div className="mb-4">
                  <label className="block text-gray-400 mb-2">In reply to (Twitter handle or URL)</label>
                  <input
                    type="text"
                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white"
                    placeholder="@username or tweet URL"
                    value={newReply.inReplyTo}
                    onChange={(e) => setNewReply({...newReply, inReplyTo: e.target.value})}
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-400 mb-2">Reply content</label>
                  <textarea
                    className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white h-32"
                    placeholder="Type your reply here..."
                    value={newReply.content}
                    onChange={(e) => setNewReply({...newReply, content: e.target.value})}
                  />
                  <div className="text-right text-gray-400 text-sm mt-1">
                    {newReply.content.length}/280
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-gray-400 mb-2">Schedule for (optional)</label>
                  <div className="flex">
                    <input
                      type="datetime-local"
                      className="flex-grow bg-gray-700 border border-gray-600 rounded-md p-3 text-white"
                      value={newReply.scheduledFor}
                      onChange={(e) => setNewReply({...newReply, scheduledFor: e.target.value})}
                    />
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={saveReply}
                    className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-md flex items-center"
                  >
                    <Save className="mr-2" size={18} />
                    Save to Queue
                  </button>
                  <button
                    onClick={() => {
                      saveReply();
                      sendReply(Date.now());
                    }}
                    className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-md flex items-center"
                    disabled={!newReply.content.trim()}
                  >
                    <Send className="mr-2" size={18} />
                    Send Now
                  </button>
                </div>
              </div>
            )}

            {/* Reply Queue */}
            {selectedTab === 'queue' && (
              <div className="bg-gray-800 p-6 rounded-xl">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">Reply Queue</h2>
                  <div className="relative">
                    <input
                      type="text"
                      className="bg-gray-700 border border-gray-600 rounded-md pl-10 pr-4 py-2 text-white w-64"
                      placeholder="Search replies..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <div className="absolute left-3 top-3 text-gray-400">
                      <Search size={16} />
                    </div>
                  </div>
                </div>

                {filteredReplies.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <List size={48} className="mx-auto mb-4 opacity-50" />
                    <p>Your reply queue is empty</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredReplies.map(reply => (
                      <div key={reply.id} className="bg-gray-700 p-4 rounded-lg">
                        <div className="flex justify-between mb-2">
                          <span className="text-blue-400">{reply.inReplyTo || 'No specific target'}</span>
                          <span className={`px-2 py-1 rounded text-xs ${
                            reply.status === 'sent' ? 'bg-green-900 text-green-300' : 'bg-blue-900 text-blue-300'
                          }`}>
                            {reply.status === 'sent' ? 'Sent' : 'Queued'}
                          </span>
                        </div>
                        <p className="mb-3">{reply.content}</p>
                        <div className="flex justify-between items-center text-sm text-gray-400">
                          <div className="flex items-center">
                            <Calendar size={14} className="mr-1" />
                            {new Date(reply.createdAt).toLocaleDateString()}
                            {reply.scheduledFor && (
                              <span className="ml-3 flex items-center">
                                <Clock size={14} className="mr-1" />
                                Scheduled: {new Date(reply.scheduledFor).toLocaleString()}
                              </span>
                            )}
                          </div>
                          <div className="flex space-x-2">
                            {reply.status !== 'sent' && (
                              <button
                                onClick={() => sendReply(reply.id)}
                                className="text-green-400 hover:text-green-300"
                                disabled={isLoading}
                              >
                                <Send size={16} />
                              </button>
                            )}
                            <button
                              onClick={() => deleteReply(reply.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default TwitterReplyManager;