import React from 'react';
import { Check } from 'lucide-react';

const tiers = [
  {
    name: 'Free',
    price: 0,
    description: 'Perfect for individuals just getting started with social media management.',
    features: [
      'Save up to 50 replies',
      'Basic tagging system',
      'Queue up to 10 tweets',
      'Manual scheduling',
      'Export/Import data',
    ],
    cta: 'Get started',
    mostPopular: false,
  },
  {
    name: 'Pro',
    price: 9,
    description: 'For social media enthusiasts who need more advanced features.',
    features: [
      'Unlimited saved replies',
      'Advanced tagging system',
      'Unlimited tweet queue',
      'Automated scheduling',
      'AI-powered reply suggestions',
      'Priority support',
    ],
    cta: 'Start free trial',
    mostPopular: true,
  },
  {
    name: 'Team',
    price: 29,
    description: 'For teams managing multiple social media accounts.',
    features: [
      'Everything in Pro',
      'Team collaboration',
      'Multiple account management',
      'Advanced analytics',
      'Custom branding',
      'API access',
      'Dedicated account manager',
    ],
    cta: 'Contact sales',
    mostPopular: false,
  },
];

const Pricing = () => {
  return (
    <div id="pricing" className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="sm:flex sm:flex-col sm:align-center">
          <h2 className="text-base font-semibold text-blue-600 tracking-wide uppercase text-center">Pricing</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl text-center">
            Plans for everyone
          </p>
          <p className="mt-5 text-xl text-gray-500 max-w-3xl mx-auto text-center">
            Choose the perfect plan for your needs. All plans include our core reply management features.
          </p>
        </div>
        <div className="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-6 lg:max-w-4xl lg:mx-auto xl:max-w-none xl:mx-0 xl:grid-cols-3">
          {tiers.map((tier) => (
            <div key={tier.name} className={`rounded-xl shadow-lg divide-y divide-gray-200 transform transition-all hover:scale-[1.02] ${tier.mostPopular ? 'border-2 border-blue-500' : 'border border-gray-200'}`}>
              {tier.mostPopular && (
                <div className="bg-blue-500 rounded-t-xl px-6 py-1">
                  <p className="text-xs font-medium text-white uppercase tracking-wide text-center">
                    Most popular
                  </p>
                </div>
              )}
              <div className="p-6">
                <h3 className="text-xl leading-6 font-bold text-gray-900">{tier.name}</h3>
                <p className="mt-4 text-sm text-gray-500">{tier.description}</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900">${tier.price}</span>
                  <span className="text-base font-medium text-gray-500">/mo</span>
                </p>
                <button
                  className={`mt-8 block w-full py-3 px-6 border border-transparent rounded-lg text-center font-medium transition-colors ${
                    tier.mostPopular
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                  }`}
                >
                  {tier.cta}
                </button>
              </div>
              <div className="pt-6 pb-8 px-6">
                <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
                <ul className="mt-6 space-y-4">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex">
                      <Check className="flex-shrink-0 h-5 w-5 text-green-500" />
                      <span className="ml-3 text-sm text-gray-500">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;