import React, { useContext, useState } from 'react';
import { Clock, MessageSquare, MoreHorizontal, Trash2, Search, Tag, Edit, Copy } from 'lucide-react';
import { ReplyContext } from '../context/ReplyContext';
import AutoSaveQueue from './AutoSaveQueue';

const SavedReplies = () => {
  const { savedReplies, removeSavedReply, addToQueue, editSavedReply } = useContext(ReplyContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest'>('newest');

  // Extract all unique tags from saved replies
  const allTags = Array.from(
    new Set(
      savedReplies.flatMap(reply => reply.tags || [])
    )
  );

  // Filter replies based on search term and selected tag
  const filteredReplies = savedReplies.filter(reply => {
    const matchesSearch = reply.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reply.inReplyTo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTag = selectedTag ? (reply.tags || []).includes(selectedTag) : true;
    return matchesSearch && matchesTag;
  });

  // Sort replies based on sort option
  const sortedReplies = [...filteredReplies].sort((a, b) => {
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        // Could add a toast notification here
        console.log('Text copied to clipboard');
      })
      .catch(err => {
        console.error('Failed to copy text: ', err);
      });
  };

  if (savedReplies.length === 0) {
    return (
      <div className="space-y-8">
        <AutoSaveQueue />
        
        <div className="bg-white rounded-xl shadow-xl p-8 transform transition-all hover:scale-[1.01]">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Saved Replies</h2>
          <div className="text-center py-12">
            <MessageSquare className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No saved replies yet</p>
            <p className="text-gray-400 mt-2">Save a reply to see it here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <AutoSaveQueue />
      
      <div className="bg-white rounded-xl shadow-xl p-8 transform transition-all hover:scale-[1.01]">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Saved Replies</h2>
        
        {/* Search and filter controls */}
        <div className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              placeholder="Search replies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Tags and sort controls */}
        <div className="flex flex-wrap items-center justify-between mb-6">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="text-sm text-gray-500 flex items-center">
              <Tag className="h-4 w-4 mr-1" /> Filter by tag:
            </span>
            <button
              className={`px-3 py-1 text-xs rounded-full ${
                selectedTag === null ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
              onClick={() => setSelectedTag(null)}
            >
              All
            </button>
            {allTags.map(tag => (
              <button
                key={tag}
                className={`px-3 py-1 text-xs rounded-full ${
                  selectedTag === tag ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedTag(tag)}
              >
                #{tag}
              </button>
            ))}
          </div>
          
          <div className="flex items-center">
            <span className="text-sm text-gray-500 mr-2">Sort:</span>
            <select
              className="text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest')}
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
            </select>
          </div>
        </div>
        
        {/* Replies list */}
        <div className="space-y-5">
          {sortedReplies.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No replies match your search criteria.</p>
            </div>
          ) : (
            sortedReplies.map((reply) => (
              <div key={reply.id} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 transition-colors">
                <div className="flex justify-between items-start mb-3">
                  <div className="text-sm text-gray-500">
                    In reply to: <span className="font-medium">{reply.inReplyTo}</span>
                  </div>
                  <div className="relative group">
                    <button className="p-1.5 rounded-full hover:bg-gray-100">
                      <MoreHorizontal className="h-5 w-5 text-gray-400" />
                    </button>
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg hidden group-hover:block z-10">
                      <div className="py-1">
                        <button 
                          onClick={() => addToQueue(reply)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <Clock className="h-4 w-4 mr-2" />
                          Add to Queue
                        </button>
                        <button 
                          onClick={() => editSavedReply(reply)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Reply
                        </button>
                        <button 
                          onClick={() => copyToClipboard(reply.text)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copy Text
                        </button>
                        <button 
                          onClick={() => removeSavedReply(reply.id)}
                          className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 w-full text-left"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="text-gray-800 whitespace-pre-wrap">{reply.text}</p>
                
                {/* Tags */}
                {reply.tags && reply.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {reply.tags.map(tag => (
                      <span 
                        key={tag} 
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 cursor-pointer hover:bg-gray-200"
                        onClick={() => setSelectedTag(tag)}
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
                
                <div className="mt-4 flex justify-between items-center">
                  <div className="text-xs text-gray-500">
                    {new Date(reply.createdAt).toLocaleDateString()} at {new Date(reply.createdAt).toLocaleTimeString()}
                  </div>
                  <button 
                    onClick={() => addToQueue(reply)}
                    className="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-lg text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors"
                  >
                    <Clock className="h-3.5 w-3.5 mr-1.5" />
                    Queue as Tweet
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default SavedReplies;