import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ReplyProvider, useReplyContext } from '../context/ReplyContext';

// Mock component to test the context
const TestComponent = () => {
  const { 
    savedReplies, 
    queuedTweets, 
    addSavedReply, 
    removeSavedReply,
    addToQueue,
    removeFromQueue
  } = useReplyContext();

  return (
    <div>
      <div data-testid="saved-count">{savedReplies.length}</div>
      <div data-testid="queued-count">{queuedTweets.length}</div>
      <button 
        data-testid="add-reply" 
        onClick={() => addSavedReply({
          id: 'test-id',
          text: 'Test reply',
          inReplyTo: 'Test user',
          createdAt: new Date().toISOString()
        })}
      >
        Add Reply
      </button>
      <button 
        data-testid="remove-reply" 
        onClick={() => savedReplies.length > 0 && removeSavedReply(savedReplies[0].id)}
      >
        Remove Reply
      </button>
      <button 
        data-testid="add-to-queue" 
        onClick={() => savedReplies.length > 0 && addToQueue(savedReplies[0])}
      >
        Add to Queue
      </button>
      <button 
        data-testid="remove-from-queue" 
        onClick={() => queuedTweets.length > 0 && removeFromQueue(queuedTweets[0].id)}
      >
        Remove from Queue
      </button>
    </div>
  );
};

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value.toString();
    },
    clear: () => {
      store = {};
    }
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock
});

describe('ReplyContext', () => {
  beforeEach(() => {
    window.localStorage.clear();
    vi.clearAllMocks();
  });

  it('should initialize with empty arrays', () => {
    render(
      <ReplyProvider>
        <TestComponent />
      </ReplyProvider>
    );

    expect(screen.getByTestId('saved-count').textContent).toBe('0');
    expect(screen.getByTestId('queued-count').textContent).toBe('0');
  });

  it('should add a saved reply', () => {
    render(
      <ReplyProvider>
        <TestComponent />
      </ReplyProvider>
    );

    fireEvent.click(screen.getByTestId('add-reply'));
    expect(screen.getByTestId('saved-count').textContent).toBe('1');
  });

  it('should remove a saved reply', () => {
    render(
      <ReplyProvider>
        <TestComponent />
      </ReplyProvider>
    );

    fireEvent.click(screen.getByTestId('add-reply'));
    expect(screen.getByTestId('saved-count').textContent).toBe('1');
    
    fireEvent.click(screen.getByTestId('remove-reply'));
    expect(screen.getByTestId('saved-count').textContent).toBe('0');
  });

  it('should add to queue', () => {
    render(
      <ReplyProvider>
        <TestComponent />
      </ReplyProvider>
    );

    fireEvent.click(screen.getByTestId('add-reply'));
    fireEvent.click(screen.getByTestId('add-to-queue'));
    
    expect(screen.getByTestId('queued-count').textContent).toBe('1');
  });

  it('should remove from queue', () => {
    render(
      <ReplyProvider>
        <TestComponent />
      </ReplyProvider>
    );

    fireEvent.click(screen.getByTestId('add-reply'));
    fireEvent.click(screen.getByTestId('add-to-queue'));
    expect(screen.getByTestId('queued-count').textContent).toBe('1');
    
    fireEvent.click(screen.getByTestId('remove-from-queue'));
    expect(screen.getByTestId('queued-count').textContent).toBe('0');
  });
});