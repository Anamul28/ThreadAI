import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';

// Initialize AI clients
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

const anthropic = new Anthropic({
  apiKey: import.meta.env.VITE_ANTHROPIC_API_KEY
});

// Types for optimization
export interface OptimizationRequest {
  originalText: string;
  targetPlatform: 'twitter' | 'linkedin' | 'facebook' | 'instagram';
  tone?: 'professional' | 'casual' | 'friendly' | 'authoritative';
  maxLength?: number;
}

export interface OptimizationResponse {
  optimizedText: string;
  suggestions: string[];
  metrics: {
    readability: number;
    engagement: number;
    clarity: number;
  };
  modelResponses: {
    gpt4: string;
    claude: string;
  };
}

export interface AIRequest {
  text: string;
  context?: string;
  tone?: 'professional' | 'casual' | 'friendly' | 'authoritative';
  maxLength?: number;
  platform?: 'twitter' | 'linkedin' | 'facebook' | 'instagram';
}

export interface AIResponse {
  gpt: {
    text: string;
    confidence: number;
  };
  claude: {
    text: string;
    confidence: number;
  };
  combined: {
    text: string;
    source: 'gpt' | 'claude' | 'hybrid';
    confidence: number;
  };
}

export async function optimizeReply(request: OptimizationRequest): Promise<OptimizationResponse> {
  try {
    const aiResponse = await generateHybridReply({
      text: request.originalText,
      platform: request.targetPlatform,
      tone: request.tone,
      maxLength: request.maxLength
    });

    // Generate alternative suggestions using both models
    const suggestions = [
      aiResponse.gpt.text,
      aiResponse.claude.text,
      aiResponse.combined.text
    ].filter((text, index, self) => 
      text !== request.originalText && 
      self.indexOf(text) === index
    );

    // Calculate metrics
    const metrics = {
      readability: Math.round(aiResponse.combined.confidence * 100),
      engagement: Math.round((aiResponse.gpt.confidence + aiResponse.claude.confidence) / 2 * 100),
      clarity: Math.round(analyzeContent(aiResponse.combined.text).clarity)
    };

    return {
      optimizedText: aiResponse.combined.text,
      suggestions: suggestions.slice(0, 3),
      metrics,
      modelResponses: {
        gpt4: aiResponse.gpt.text,
        claude: aiResponse.claude.text
      }
    };
  } catch (error) {
    console.error('Error optimizing reply:', error);
    throw error;
  }
}

export async function generateHybridReply(request: AIRequest): Promise<AIResponse> {
  try {
    // Generate replies from both models in parallel
    const [gptResponse, claudeResponse] = await Promise.all([
      generateGPTReply(request),
      generateClaudeReply(request)
    ]);

    // Combine responses using advanced hybrid strategy
    const combined = hybridCombineResponses(gptResponse, claudeResponse, request);

    return {
      gpt: gptResponse,
      claude: claudeResponse,
      combined
    };
  } catch (error) {
    console.error('Error generating hybrid AI replies:', error);
    throw error;
  }
}

async function generateGPTReply(request: AIRequest) {
  const prompt = createPrompt(request, 'gpt');
  
  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are an expert social media manager helping craft the perfect reply.'
      },
      {
        role: 'user',
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: request.maxLength || 280
  });

  const text = response.choices[0]?.message?.content || '';
  const confidence = calculateConfidence(response);

  return { text, confidence };
}

async function generateClaudeReply(request: AIRequest) {
  const prompt = createPrompt(request, 'claude');

  const response = await anthropic.messages.create({
    model: 'claude-3-opus-20240229',
    max_tokens: request.maxLength || 280,
    temperature: 0.7,
    messages: [
      {
        role: 'user',
        content: prompt
      }
    ]
  });

  const text = response.content[0].text;
  const confidence = calculateConfidence(response);

  return { text, confidence };
}

function createPrompt(request: AIRequest, model: 'gpt' | 'claude'): string {
  const { text, context, tone, platform } = request;
  
  let prompt = `Generate a ${tone || 'professional'} reply`;
  
  if (platform) {
    prompt += ` optimized for ${platform}`;
  }
  
  if (context) {
    prompt += `\n\nContext: ${context}`;
  }
  
  prompt += `\n\nOriginal text: "${text}"`;
  
  if (platform === 'twitter') {
    prompt += '\n\nEnsure the reply is within 280 characters.';
  }

  // Add model-specific instructions
  if (model === 'gpt') {
    prompt += '\n\nFocus on engagement and natural language.';
  } else {
    prompt += '\n\nPrioritize accuracy and professionalism.';
  }

  return prompt;
}

function calculateConfidence(response: any): number {
  // Enhanced confidence calculation
  let baseConfidence = 0.85;
  
  try {
    if ('choices' in response) {
      // GPT response
      const choice = response.choices[0];
      if (choice.finish_reason === 'stop') baseConfidence += 0.05;
      if (choice.message?.role === 'assistant') baseConfidence += 0.05;
    } else if ('content' in response) {
      // Claude response
      if (response.content.length > 0) baseConfidence += 0.05;
      if (response.stop_reason === 'end_turn') baseConfidence += 0.05;
    }
  } catch (error) {
    console.warn('Error calculating confidence:', error);
  }

  // Add small random variation
  return Math.min(baseConfidence + (Math.random() * 0.05), 1);
}

function hybridCombineResponses(
  gpt: { text: string; confidence: number },
  claude: { text: string; confidence: number },
  request: AIRequest
): { text: string; source: 'gpt' | 'claude' | 'hybrid'; confidence: number } {
  const confidenceDiff = Math.abs(gpt.confidence - claude.confidence);
  const similarityScore = calculateTextSimilarity(gpt.text, claude.text);

  // If responses are very similar, use the higher confidence one
  if (similarityScore > 0.8) {
    return gpt.confidence > claude.confidence
      ? { text: gpt.text, source: 'gpt', confidence: gpt.confidence }
      : { text: claude.text, source: 'claude', confidence: claude.confidence };
  }

  // If one model is significantly more confident, use its response
  if (confidenceDiff > 0.2) {
    return gpt.confidence > claude.confidence
      ? { text: gpt.text, source: 'gpt', confidence: gpt.confidence }
      : { text: claude.text, source: 'claude', confidence: claude.confidence };
  }

  // Create a hybrid response
  const hybridText = createHybridText(gpt.text, claude.text, request);
  const hybridConfidence = Math.max(gpt.confidence, claude.confidence) + 0.05;

  return {
    text: hybridText,
    source: 'hybrid',
    confidence: Math.min(hybridConfidence, 1)
  };
}

function calculateTextSimilarity(text1: string, text2: string): number {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));
  
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);
  
  return intersection.size / union.size;
}

function createHybridText(gptText: string, claudeText: string, request: AIRequest): string {
  // Split texts into sentences
  const gptSentences = gptText.match(/[^.!?]+[.!?]+/g) || [gptText];
  const claudeSentences = claudeText.match(/[^.!?]+[.!?]+/g) || [claudeText];
  
  // Initialize hybrid text with the stronger opening
  let hybridText = gptSentences[0].trim();
  
  // Add unique insights from both models
  const maxLength = request.maxLength || 280;
  let currentLength = hybridText.length;
  
  // Alternate between models for remaining sentences
  let useGPT = false;
  for (let i = 1; i < Math.max(gptSentences.length, claudeSentences.length); i++) {
    const nextSentence = useGPT
      ? gptSentences[i]
      : claudeSentences[i];
    
    if (nextSentence && currentLength + nextSentence.length + 1 <= maxLength) {
      hybridText += ' ' + nextSentence.trim();
      currentLength += nextSentence.length + 1;
    }
    
    useGPT = !useGPT;
  }
  
  return hybridText;
}

export function analyzeContent(text: string): {
  wordCount: number;
  readTime: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  keywords: string[];
  clarity: number;
} {
  const words = text.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const readTime = Math.max(Math.ceil(wordCount / 200), 1);

  const positiveWords = ['good', 'great', 'excellent', 'amazing', 'love', 'best', 'happy', 'thank', 'thanks', 'appreciate'];
  const negativeWords = ['bad', 'poor', 'terrible', 'awful', 'hate', 'worst', 'sad', 'sorry', 'problem', 'issue'];

  let positiveCount = 0;
  let negativeCount = 0;

  words.forEach(word => {
    const lowerWord = word.toLowerCase();
    if (positiveWords.includes(lowerWord)) positiveCount++;
    if (negativeWords.includes(lowerWord)) negativeCount++;
  });

  let sentiment: 'positive' | 'neutral' | 'negative' = 'neutral';
  if (positiveCount > negativeCount) sentiment = 'positive';
  else if (negativeCount > positiveCount) sentiment = 'negative';

  const stopWords = ['the', 'and', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
  const keywords = words
    .map(word => word.toLowerCase())
    .filter(word => word.length > 3 && !stopWords.includes(word))
    .reduce((acc: { [key: string]: number }, word) => {
      acc[word] = (acc[word] || 0) + 1;
      return acc;
    }, {});

  const topKeywords = Object.entries(keywords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([word]) => word);

  const clarity = Math.min(
    Math.round(
      (100 - Math.abs(wordCount - 20)) * 0.5 + // Optimal length
      (sentiment !== 'neutral' ? 25 : 0) + // Clear sentiment
      (topKeywords.length >= 3 ? 25 : topKeywords.length * 8) // Good keyword density
    ),
    100
  );

  return {
    wordCount,
    readTime,
    sentiment,
    keywords: topKeywords,
    clarity
  };
}