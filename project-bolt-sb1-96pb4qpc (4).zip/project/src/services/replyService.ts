import { supabase } from '../lib/supabase';
import { v4 as uuidv4 } from 'uuid';
import { AIResponse } from './aiService';

export interface Reply {
  id: string;
  text: string;
  inReplyTo: string;
  tags?: string[];
  createdAt: string;
  aiMetadata?: {
    source: 'gpt' | 'claude' | 'hybrid';
    confidence: number;
    metrics?: {
      readability: number;
      engagement: number;
      clarity: number;
    };
  };
}

export interface Tweet extends Reply {
  scheduledFor?: string;
}

export async function saveAIGeneratedReply(
  aiResponse: AIResponse,
  inReplyTo: string,
  tags: string[] = []
): Promise<Reply | null> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return null;

  const newReply = {
    id: uuidv4(),
    user_id: user.data.user.id,
    text: aiResponse.combined.text,
    in_reply_to: inReplyTo,
    tags,
    created_at: new Date().toISOString(),
    ai_metadata: {
      source: aiResponse.combined.source,
      confidence: aiResponse.combined.confidence,
      gpt_response: aiResponse.gpt.text,
      claude_response: aiResponse.claude.text
    }
  };

  const { data, error } = await supabase
    .from('replies')
    .insert([newReply])
    .select()
    .single();

  if (error) {
    console.error('Error saving AI reply:', error);
    return null;
  }

  return {
    id: data.id,
    text: data.text,
    inReplyTo: data.in_reply_to,
    tags: data.tags || [],
    createdAt: data.created_at,
    aiMetadata: {
      source: data.ai_metadata.source,
      confidence: data.ai_metadata.confidence
    }
  };
}

export async function fetchReplies(): Promise<Reply[]> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return [];

  const { data, error } = await supabase
    .from('replies')
    .select('*')
    .eq('user_id', user.data.user.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching replies:', error);
    return [];
  }

  return data.map(item => ({
    id: item.id,
    text: item.text,
    inReplyTo: item.in_reply_to,
    tags: item.tags || [],
    createdAt: item.created_at,
    aiMetadata: item.ai_metadata
  }));
}

export async function saveReply(reply: Omit<Reply, 'id' | 'createdAt'>): Promise<Reply | null> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return null;

  const newReply = {
    id: uuidv4(),
    user_id: user.data.user.id,
    text: reply.text,
    in_reply_to: reply.inReplyTo,
    tags: reply.tags || [],
    created_at: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from('replies')
    .insert([newReply])
    .select()
    .single();

  if (error) {
    console.error('Error saving reply:', error);
    return null;
  }

  return {
    id: data.id,
    text: data.text,
    inReplyTo: data.in_reply_to,
    tags: data.tags || [],
    createdAt: data.created_at
  };
}

export async function updateReply(reply: Reply): Promise<Reply | null> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return null;

  const { data, error } = await supabase
    .from('replies')
    .update({
      text: reply.text,
      in_reply_to: reply.inReplyTo,
      tags: reply.tags
    })
    .eq('id', reply.id)
    .eq('user_id', user.data.user.id)
    .select()
    .single();

  if (error) {
    console.error('Error updating reply:', error);
    return null;
  }

  return {
    id: data.id,
    text: data.text,
    inReplyTo: data.in_reply_to,
    tags: data.tags || [],
    createdAt: data.created_at,
    aiMetadata: data.ai_metadata
  };
}

export async function deleteReply(id: string): Promise<boolean> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return false;

  const { error } = await supabase
    .from('replies')
    .delete()
    .eq('id', id)
    .eq('user_id', user.data.user.id);

  if (error) {
    console.error('Error deleting reply:', error);
    return false;
  }

  return true;
}

export async function fetchTweets(): Promise<Tweet[]> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return [];

  const { data, error } = await supabase
    .from('tweets')
    .select('*')
    .eq('user_id', user.data.user.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching tweets:', error);
    return [];
  }

  return data.map(item => ({
    id: item.id,
    text: item.text,
    inReplyTo: '', // Tweets don't have an in_reply_to field in this context
    scheduledFor: item.scheduled_for,
    createdAt: item.created_at,
    aiMetadata: item.ai_metadata
  }));
}

export async function saveTweet(tweet: Omit<Tweet, 'id' | 'createdAt'>): Promise<Tweet | null> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return null;

  const newTweet = {
    id: uuidv4(),
    user_id: user.data.user.id,
    text: tweet.text,
    reply_id: tweet.id, // If this tweet was created from a reply
    scheduled_for: tweet.scheduledFor,
    created_at: new Date().toISOString(),
    ai_metadata: tweet.aiMetadata
  };

  const { data, error } = await supabase
    .from('tweets')
    .insert([newTweet])
    .select()
    .single();

  if (error) {
    console.error('Error saving tweet:', error);
    return null;
  }

  return {
    id: data.id,
    text: data.text,
    inReplyTo: '', // Tweets don't have an in_reply_to field in this context
    scheduledFor: data.scheduled_for,
    createdAt: data.created_at,
    aiMetadata: data.ai_metadata
  };
}

export async function updateTweetSchedule(id: string, scheduledFor: string): Promise<boolean> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return false;

  const { error } = await supabase
    .from('tweets')
    .update({ scheduled_for: scheduledFor })
    .eq('id', id)
    .eq('user_id', user.data.user.id);

  if (error) {
    console.error('Error updating tweet schedule:', error);
    return false;
  }

  return true;
}

export async function deleteTweet(id: string): Promise<boolean> {
  const user = await supabase.auth.getUser();
  if (!user.data.user) return false;

  const { error } = await supabase
    .from('tweets')
    .delete()
    .eq('id', id)
    .eq('user_id', user.data.user.id);

  if (error) {
    console.error('Error deleting tweet:', error);
    return false;
  }

  return true;
}