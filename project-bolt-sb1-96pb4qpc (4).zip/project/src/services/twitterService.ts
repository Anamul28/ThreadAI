import { twitterConfig, validateTwitterConfig, getConfigErrorMessage, getApiBaseUrl } from '../config/twitter';

async function fetchWithAuth(endpoint: string, options: RequestInit = {}) {
  const baseUrl = getApiBaseUrl();
  
  try {
    const response = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || `HTTP error! status: ${response.status}`);
    }

    return response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

export async function authenticateTwitter() {
  try {
    // First validate the Twitter config
    if (!validateTwitterConfig()) {
      return { 
        success: false, 
        error: getConfigErrorMessage()
      };
    }

    // Check API health
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/health`);
    
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || 'Twitter API health check failed');
    }

    const data = await response.json();
    
    if (data.status !== 'ok') {
      throw new Error('Twitter API health check failed');
    }

    return { success: true };
  } catch (error) {
    console.error('Twitter authentication error:', error);
    return { 
      success: false, 
      error: error instanceof Error 
        ? error.message 
        : 'Failed to authenticate with Twitter. Please check your credentials and try again.'
    };
  }
}

export async function fetchHomeTimeline(count: number = 20) {
  if (!validateTwitterConfig()) {
    throw new Error(getConfigErrorMessage());
  }
  return fetchWithAuth(`/timeline?count=${count}`);
}

export async function searchTweets(query: string, count: number = 20) {
  if (!validateTwitterConfig()) {
    throw new Error(getConfigErrorMessage());
  }
  return fetchWithAuth('/search', {
    method: 'POST',
    body: JSON.stringify({ query, count }),
  });
}

export async function fetchTweetThread(tweetId: string) {
  if (!validateTwitterConfig()) {
    throw new Error(getConfigErrorMessage());
  }
  return fetchWithAuth(`/thread/${tweetId}`);
}

export async function fetchMentions(count: number = 20) {
  if (!validateTwitterConfig()) {
    throw new Error(getConfigErrorMessage());
  }
  return fetchWithAuth(`/mentions?count=${count}`);
}

export async function sendReply(tweetId: string, text: string) {
  if (!validateTwitterConfig()) {
    throw new Error(getConfigErrorMessage());
  }
  return fetchWithAuth('/reply', {
    method: 'POST',
    body: JSON.stringify({ tweetId, text }),
  });
}

export async function getTwitterProfile() {
  if (!validateTwitterConfig()) {
    return null;
  }
  try {
    const response = await fetchWithAuth('/profile');
    return response;
  } catch (error) {
    console.error('Error fetching Twitter profile:', error);
    return null;
  }
}