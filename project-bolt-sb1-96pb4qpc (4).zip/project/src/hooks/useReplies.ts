import { useState, useEffect } from 'react';
import { 
  fetchReplies, 
  saveAIGeneratedReply,
  saveReply, 
  updateReply, 
  deleteReply,
  Reply,
  Tweet,
  saveTweet,
  updateTweetSchedule,
  deleteTweet
} from '../services/replyService';
import { AIResponse } from '../services/aiService';
import { supabase } from '../lib/supabase';

export function useReplies() {
  const [replies, setReplies] = useState<Reply[]>([]);
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadReplies();
    
    // Subscribe to real-time updates
    const repliesSubscription = supabase
      .channel('replies-changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'replies' 
      }, () => {
        loadReplies();
      })
      .subscribe();

    const tweetsSubscription = supabase
      .channel('tweets-changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'tweets' 
      }, () => {
        loadTweets();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(repliesSubscription);
      supabase.removeChannel(tweetsSubscription);
    };
  }, []);

  const loadReplies = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchReplies();
      setReplies(data);
    } catch (err) {
      setError('Failed to load replies');
    } finally {
      setIsLoading(false);
    }
  };

  const loadTweets = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchReplies();
      setTweets(data);
    } catch (err) {
      setError('Failed to load tweets');
    } finally {
      setIsLoading(false);
    }
  };

  const saveAIReply = async (
    aiResponse: AIResponse,
    inReplyTo: string,
    tags: string[] = []
  ): Promise<Reply | null> => {
    setError(null);
    try {
      const savedReply = await saveAIGeneratedReply(aiResponse, inReplyTo, tags);
      if (savedReply) {
        setReplies(prev => [savedReply, ...prev]);
      }
      return savedReply;
    } catch (err) {
      setError('Failed to save AI reply');
      return null;
    }
  };

  const addReply = async (reply: Omit<Reply, 'id' | 'createdAt'>): Promise<Reply | null> => {
    setError(null);
    try {
      const savedReply = await saveReply(reply);
      if (savedReply) {
        setReplies(prev => [savedReply, ...prev]);
      }
      return savedReply;
    } catch (err) {
      setError('Failed to save reply');
      return null;
    }
  };

  const editReply = async (reply: Reply): Promise<Reply | null> => {
    setError(null);
    try {
      const updatedReply = await updateReply(reply);
      if (updatedReply) {
        setReplies(prev => 
          prev.map(r => r.id === reply.id ? updatedReply : r)
        );
      }
      return updatedReply;
    } catch (err) {
      setError('Failed to update reply');
      return null;
    }
  };

  const removeReply = async (id: string): Promise<boolean> => {
    setError(null);
    try {
      const success = await deleteReply(id);
      if (success) {
        setReplies(prev => prev.filter(reply => reply.id !== id));
      }
      return success;
    } catch (err) {
      setError('Failed to delete reply');
      return false;
    }
  };

  const queueTweet = async (reply: Reply, scheduledFor?: string): Promise<Tweet | null> => {
    setError(null);
    try {
      const tweet: Omit<Tweet, 'id' | 'createdAt'> = {
        ...reply,
        scheduledFor
      };
      
      const savedTweet = await saveTweet(tweet);
      if (savedTweet) {
        setTweets(prev => [savedTweet, ...prev]);
      }
      return savedTweet;
    } catch (err) {
      setError('Failed to queue tweet');
      return null;
    }
  };

  const scheduleTweet = async (id: string, scheduledFor: string): Promise<boolean> => {
    setError(null);
    try {
      const success = await updateTweetSchedule(id, scheduledFor);
      if (success) {
        setTweets(prev => 
          prev.map(tweet => 
            tweet.id === id ? { ...tweet, scheduledFor } : tweet
          )
        );
      }
      return success;
    } catch (err) {
      setError('Failed to schedule tweet');
      return false;
    }
  };

  const removeTweet = async (id: string): Promise<boolean> => {
    setError(null);
    try {
      const success = await deleteTweet(id);
      if (success) {
        setTweets(prev => prev.filter(tweet => tweet.id !== id));
      }
      return success;
    } catch (err) {
      setError('Failed to delete tweet');
      return false;
    }
  };

  return {
    replies,
    tweets,
    isLoading,
    error,
    saveAIReply,
    addReply,
    editReply,
    removeReply,
    queueTweet,
    scheduleTweet,
    removeTweet
  };
}