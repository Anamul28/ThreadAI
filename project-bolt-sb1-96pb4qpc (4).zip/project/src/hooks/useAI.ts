import { useState } from 'react';
import { generateOptimalReply, AIRequest, AIResponse } from '../services/aiService';

export function useAI() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateReply = async (request: AIRequest): Promise<AIResponse | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await generateOptimalReply(request);
      return response;
    } catch (err: any) {
      setError(err.message || 'Failed to generate AI reply');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    generateReply,
    isLoading,
    error
  };
}