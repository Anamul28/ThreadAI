import { useState, useEffect } from 'react';
import { 
  fetchHomeTimeline, 
  fetchMentions, 
  searchTweets, 
  fetchTweetThread,
  authenticateTwitter
} from '../services/twitterService';

export function useTwitter() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const { success } = await authenticateTwitter();
      setIsAuthenticated(success);
    } catch (err) {
      setError('Failed to authenticate with Twitter');
      setIsAuthenticated(false);
    }
  };

  const getHomeTimeline = async (count?: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const timeline = await fetchHomeTimeline(count);
      return timeline;
    } catch (err) {
      setError('Failed to fetch timeline');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getMentions = async (count?: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const mentions = await fetchMentions(count);
      return mentions;
    } catch (err) {
      setError('Failed to fetch mentions');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const search = async (query: string, count?: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await searchTweets(query, count);
      return results;
    } catch (err) {
      setError('Failed to search tweets');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getThread = async (tweetId: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const thread = await fetchTweetThread(tweetId);
      return thread;
    } catch (err) {
      setError('Failed to fetch thread');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isAuthenticated,
    isLoading,
    error,
    getHomeTimeline,
    getMentions,
    search,
    getThread
  };
}