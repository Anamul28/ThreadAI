import React, { createContext, useState, useEffect, ReactNode, useContext } from 'react';
import EditReplyModal from '../components/EditReplyModal';
import { 
  fetchReplies, 
  saveReply, 
  updateReply, 
  deleteReply,
  fetchTweets,
  saveTweet,
  updateTweetSchedule,
  deleteTweet,
  Reply,
  Tweet
} from '../services/replyService';
import { supabase } from '../lib/supabase';

interface ReplyContextType {
  savedReplies: Reply[];
  queuedTweets: Tweet[];
  addSavedReply: (reply: Omit<Reply, 'id' | 'createdAt'>) => void;
  removeSavedReply: (id: string) => void;
  editSavedReply: (reply: Reply) => void;
  addToQueue: (reply: Reply) => void;
  removeFromQueue: (id: string) => void;
  reorderQueue: (fromIndex: number, toIndex: number) => void;
  scheduleTweet: (id: string, scheduledTime: string) => void;
  exportData: () => string;
  importData: (jsonData: string) => void;
  loading: boolean;
}

export const ReplyContext = createContext<ReplyContextType>({
  savedReplies: [],
  queuedTweets: [],
  addSavedReply: () => {},
  removeSavedReply: () => {},
  editSavedReply: () => {},
  addToQueue: () => {},
  removeFromQueue: () => {},
  reorderQueue: () => {},
  scheduleTweet: () => {},
  exportData: () => '',
  importData: () => {},
  loading: false,
});

// Custom hook to use the reply context
export const useReplyContext = () => useContext(ReplyContext);

interface ReplyProviderProps {
  children: ReactNode;
}

export const ReplyProvider = ({ children }: ReplyProviderProps) => {
  const [savedReplies, setSavedReplies] = useState<Reply[]>([]);
  const [queuedTweets, setQueuedTweets] = useState<Tweet[]>([]);
  const [replyToEdit, setReplyToEdit] = useState<Reply | null>(null);
  const [loading, setLoading] = useState(true);

  // Load data from Supabase when the component mounts or user changes
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [repliesData, tweetsData] = await Promise.all([
          fetchReplies(),
          fetchTweets()
        ]);
        
        setSavedReplies(repliesData);
        setQueuedTweets(tweetsData);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    };

    // Load initial data
    loadData();

    // Set up auth state listener
    const { data: authListener } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') {
        loadData();
      } else if (event === 'SIGNED_OUT') {
        setSavedReplies([]);
        setQueuedTweets([]);
      }
    });

    // Set up realtime subscription for replies
    const repliesSubscription = supabase
      .channel('replies-changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'replies' 
      }, () => {
        fetchReplies().then(data => setSavedReplies(data));
      })
      .subscribe();

    // Set up realtime subscription for tweets
    const tweetsSubscription = supabase
      .channel('tweets-changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'tweets' 
      }, () => {
        fetchTweets().then(data => setQueuedTweets(data));
      })
      .subscribe();

    return () => {
      // Clean up subscriptions
      authListener.subscription.unsubscribe();
      supabase.removeChannel(repliesSubscription);
      supabase.removeChannel(tweetsSubscription);
    };
  }, []);

  const addSavedReply = async (reply: Omit<Reply, 'id' | 'createdAt'>) => {
    const newReply = await saveReply(reply);
    if (newReply) {
      setSavedReplies((prev) => [newReply, ...prev]);
    }
  };

  const removeSavedReply = async (id: string) => {
    const success = await deleteReply(id);
    if (success) {
      setSavedReplies((prev) => prev.filter((reply) => reply.id !== id));
    }
  };

  const editSavedReply = (reply: Reply) => {
    setReplyToEdit(reply);
  };

  const handleSaveEdit = async (updatedReply: Reply) => {
    const result = await updateReply(updatedReply);
    if (result) {
      setSavedReplies(prev => 
        prev.map(reply => 
          reply.id === updatedReply.id ? updatedReply : reply
        )
      );
    }
    setReplyToEdit(null);
  };

  const addToQueue = async (reply: Reply) => {
    // Check if already in queue
    if (!queuedTweets.some(tweet => tweet.id === reply.id)) {
      const newTweet = await saveTweet({
        ...reply,
        scheduledFor: undefined
      });
      
      if (newTweet) {
        setQueuedTweets((prev) => [newTweet, ...prev]);
      }
    }
  };

  const removeFromQueue = async (id: string) => {
    const success = await deleteTweet(id);
    if (success) {
      setQueuedTweets((prev) => prev.filter((tweet) => tweet.id !== id));
    }
  };

  const reorderQueue = (fromIndex: number, toIndex: number) => {
    const newQueue = [...queuedTweets];
    const [movedItem] = newQueue.splice(fromIndex, 1);
    newQueue.splice(toIndex, 0, movedItem);
    setQueuedTweets(newQueue);
    // Note: This doesn't update the order in the database
    // In a real app, you'd want to store and sync the order
  };

  const scheduleTweet = async (id: string, scheduledTime: string) => {
    const success = await updateTweetSchedule(id, scheduledTime);
    if (success) {
      setQueuedTweets(prev => 
        prev.map(tweet => 
          tweet.id === id ? { ...tweet, scheduledFor: scheduledTime } : tweet
        )
      );
    }
  };

  const exportData = () => {
    const data = {
      savedReplies,
      queuedTweets,
      exportDate: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  };

  const importData = (jsonData: string) => {
    try {
      const data = JSON.parse(jsonData);
      if (data.savedReplies) {
        // In a real app, you'd want to sync this with the database
        // For now, we'll just update the local state
        setSavedReplies(data.savedReplies);
      }
      if (data.queuedTweets) {
        setQueuedTweets(data.queuedTweets);
      }
    } catch (error) {
      console.error('Error parsing import data:', error);
      throw new Error('Invalid import data format');
    }
  };

  return (
    <ReplyContext.Provider
      value={{
        savedReplies,
        queuedTweets,
        addSavedReply,
        removeSavedReply,
        editSavedReply,
        addToQueue,
        removeFromQueue,
        reorderQueue,
        scheduleTweet,
        exportData,
        importData,
        loading,
      }}
    >
      {children}
      {replyToEdit && (
        <EditReplyModal 
          reply={replyToEdit} 
          onSave={handleSaveEdit} 
          onCancel={() => setReplyToEdit(null)} 
        />
      )}
    </ReplyContext.Provider>
  );
};