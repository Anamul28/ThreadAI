/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_TWITTER_API_KEY: string
  readonly VITE_TWITTER_API_SECRET: string
  readonly VITE_TWITTER_ACCESS_TOKEN: string
  readonly VITE_TWITTER_ACCESS_TOKEN_SECRET: string
  readonly VITE_TWITTER_BEARER_TOKEN: string
  readonly VITE_SUPABASE_URL: string
  readonly VITE_SUPABASE_ANON_KEY: string
  readonly VITE_OPENAI_API_KEY: string
  readonly VITE_ANTHROPIC_API_KEY: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}