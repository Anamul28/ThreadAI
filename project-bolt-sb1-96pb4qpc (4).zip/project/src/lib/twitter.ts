import { TwitterApi } from 'twitter-api-v2';

let twitterClient: TwitterApi | null = null;

interface TwitterConfig {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
  accessTokenSecret: string;
  bearerToken?: string;
}

function validateConfig(config: TwitterConfig): void {
  if (!config.apiKey) throw new Error('Twitter API Key is required');
  if (!config.apiSecret) throw new Error('Twitter API Secret is required');
  if (!config.accessToken) throw new Error('Twitter Access Token is required');
  if (!config.accessTokenSecret) throw new Error('Twitter Access Token Secret is required');
}

export function initializeTwitterClient(config: TwitterConfig): TwitterApi {
  try {
    validateConfig(config);

    // Create OAuth 1.0a client
    const client = new TwitterApi({
      appKey: config.apiKey,
      appSecret: config.apiSecret,
      accessToken: config.accessToken,
      accessSecret: config.accessTokenSecret,
    });

    // Store the client instance
    twitterClient = client;

    return client;
  } catch (error) {
    console.error('Error initializing Twitter client:', error);
    throw error;
  }
}

export function getTwitterClient(): TwitterApi {
  if (!twitterClient) {
    const config = {
      apiKey: import.meta.env.VITE_TWITTER_API_KEY,
      apiSecret: import.meta.env.VITE_TWITTER_API_SECRET,
      accessToken: import.meta.env.VITE_TWITTER_ACCESS_TOKEN,
      accessTokenSecret: import.meta.env.VITE_TWITTER_ACCESS_TOKEN_SECRET,
      bearerToken: import.meta.env.VITE_TWITTER_BEARER_TOKEN,
    };

    return initializeTwitterClient(config);
  }

  return twitterClient;
}

// Initialize the client immediately with error handling
try {
  getTwitterClient();
} catch (error) {
  console.error('Failed to initialize Twitter client:', error);
}