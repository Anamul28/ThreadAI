import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

// Get environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Validate environment variables
if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    'Supabase credentials not found. Please click "Connect to Supabase" button to set up your database connection.'
  );
}

// Create Supabase client with proper URL validation
const getValidUrl = (url: string) => {
  try {
    return new URL(url).toString();
  } catch {
    return 'https://placeholder-project.supabase.co';
  }
};

// Initialize client with validated URL
export const supabase = createClient<Database>(
  getValidUrl(supabaseUrl || ''),
  supabaseAnonKey || 'placeholder-key'
);

// Auth functions
export async function signUp(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  return { data, error };
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  return { error };
}

export async function getCurrentUser() {
  const { data } = await supabase.auth.getUser();
  return data?.user;
}