import React from 'react';
import { MessageSquare, Clock, Tag, Save } from 'lucide-react';

const features = [
  {
    name: 'Save Thoughtful Replies',
    description: 'Store your well-crafted responses for future use. Never lose a brilliant reply again.',
    icon: Save,
  },
  {
    name: 'Tag and Categorize',
    description: 'Organize replies with custom tags for easy filtering and retrieval when you need them.',
    icon: Tag,
  },
  {
    name: 'Queue as Tweets',
    description: 'Convert your best replies into standalone tweets to maximize their visibility and impact.',
    icon: MessageSquare,
  },
  {
    name: 'Schedule Posts',
    description: 'Set specific dates and times for your queued tweets to optimize engagement with your audience.',
    icon: Clock,
  },
];

const Features = () => {
  return (
    <div id="features" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            A better way to manage your social media content
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our revolutionary platform helps you save, organize, and schedule your best social media content.
          </p>
        </div>

        <div className="mt-16">
          <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-16">
            {features.map((feature) => (
              <div key={feature.name} className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-16 w-16 rounded-xl bg-blue-500 text-white">
                    <feature.icon className="h-8 w-8" aria-hidden="true" />
                  </div>
                  <p className="ml-20 text-xl leading-6 font-bold text-gray-900">{feature.name}</p>
                </dt>
                <dd className="mt-2 ml-20 text-base text-gray-500">{feature.description}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export default Features;