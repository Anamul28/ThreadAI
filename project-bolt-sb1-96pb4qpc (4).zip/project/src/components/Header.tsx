import React, { useState } from 'react';
import { MessageSquare, Settings, HelpCircle, Download, Upload, LogOut } from 'lucide-react';
import { useReplyContext } from '../context/ReplyContext';
import { signOut } from '../lib/supabase';

const Header = () => {
  const { exportData, importData } = useReplyContext();
  const [showSettings, setShowSettings] = useState(false);
  const [fileInput, setFileInput] = useState<HTMLInputElement | null>(null);

  const handleExport = () => {
    const dataStr = exportData();
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `threadai-export-${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportClick = () => {
    if (fileInput) {
      fileInput.click();
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        importData(content);
        // Reset file input
        if (fileInput) {
          fileInput.value = '';
        }
      } catch (error) {
        console.error('Error importing data:', error);
        alert('Failed to import data. The file might be corrupted or in the wrong format.');
      }
    };
    reader.readAsText(file);
  };

  const handleSignOut = async () => {
    await signOut();
    setShowSettings(false);
  };

  return (
    <header className="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <MessageSquare className="h-10 w-10 text-white" />
            <h1 className="ml-3 text-3xl font-bold text-white">ThreadAI</h1>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 text-white hover:text-blue-200 hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
              title="Settings"
            >
              <Settings className="h-6 w-6" />
            </button>
            <button 
              className="p-2 text-white hover:text-blue-200 hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
              title="Help"
            >
              <HelpCircle className="h-6 w-6" />
            </button>
            <button className="bg-white text-blue-600 hover:bg-blue-50 px-5 py-2.5 rounded-md text-sm font-medium transition-colors">
              Connect Twitter
            </button>
          </div>
        </div>
        
        {/* Settings dropdown */}
        {showSettings && (
          <div className="absolute right-4 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
            <div className="py-1">
              <button 
                onClick={handleExport}
                className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
              >
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </button>
              <button 
                onClick={handleImportClick}
                className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
              >
                <Upload className="h-4 w-4 mr-2" />
                Import Data
              </button>
              <button 
                onClick={handleSignOut}
                className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 w-full text-left"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </button>
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleFileChange}
                ref={(input) => setFileInput(input)}
              />
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;