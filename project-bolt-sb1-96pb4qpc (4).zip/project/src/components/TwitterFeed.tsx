import React, { useState, useEffect } from 'react';
import { useTwitter } from '../hooks/useTwitter';
import { RefreshCw, MessageCircle, Repeat2, Heart, Share } from 'lucide-react';

interface Tweet {
  id: string;
  text: string;
  created_at: string;
  public_metrics?: {
    retweet_count: number;
    reply_count: number;
    like_count: number;
  };
  author?: {
    name: string;
    username: string;
    profile_image_url?: string;
  };
}

const TwitterFeed: React.FC = () => {
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const { getHomeTimeline, isLoading, error } = useTwitter();

  useEffect(() => {
    loadTweets();
  }, []);

  const loadTweets = async () => {
    const timeline = await getHomeTimeline(20);
    if (timeline) {
      setTweets(timeline);
    }
  };

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Home Timeline</h2>
        <button 
          onClick={loadTweets}
          className="p-2 text-gray-500 hover:text-blue-500 rounded-full hover:bg-blue-50 transition-colors"
          disabled={isLoading}
        >
          <RefreshCw className={`h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {tweets.map((tweet) => (
            <div key={tweet.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
              <div className="flex items-start mb-3">
                {tweet.author?.profile_image_url && (
                  <img 
                    src={tweet.author.profile_image_url} 
                    alt={tweet.author.name}
                    className="h-10 w-10 rounded-full mr-3"
                  />
                )}
                <div>
                  <div className="font-semibold">{tweet.author?.name}</div>
                  <div className="text-gray-500">@{tweet.author?.username}</div>
                </div>
              </div>
              
              <p className="text-gray-800 mb-3">{tweet.text}</p>
              
              <div className="flex items-center justify-between text-gray-500 text-sm">
                <button className="flex items-center hover:text-blue-500">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  {tweet.public_metrics?.reply_count || 0}
                </button>
                <button className="flex items-center hover:text-green-500">
                  <Repeat2 className="h-4 w-4 mr-1" />
                  {tweet.public_metrics?.retweet_count || 0}
                </button>
                <button className="flex items-center hover:text-red-500">
                  <Heart className="h-4 w-4 mr-1" />
                  {tweet.public_metrics?.like_count || 0}
                </button>
                <button className="flex items-center hover:text-blue-500">
                  <Share className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TwitterFeed;