// Twitter API configuration types and validation
interface TwitterConfig {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
  accessTokenSecret: string;
  bearerToken: string;
}

// Load environment variables with validation
export const twitterConfig: TwitterConfig = {
  apiKey: import.meta.env.VITE_TWITTER_API_KEY || '',
  apiSecret: import.meta.env.VITE_TWITTER_API_SECRET || '',
  accessToken: import.meta.env.VITE_TWITTER_ACCESS_TOKEN || '',
  accessTokenSecret: import.meta.env.VITE_TWITTER_ACCESS_TOKEN_SECRET || '',
  bearerToken: import.meta.env.VITE_TWITTER_BEARER_TOKEN || ''
};

// Validate configuration
export function validateTwitterConfig(): boolean {
  const requiredFields: (keyof TwitterConfig)[] = [
    'apiKey',
    'apiSecret',
    'accessToken',
    'accessTokenSecret'
  ];

  const missingFields = requiredFields.filter(field => !twitterConfig[field]);

  if (missingFields.length > 0) {
    console.error('Missing Twitter configuration fields:', missingFields);
    return false;
  }

  return true;
}

// Get error message for missing configuration
export function getConfigErrorMessage(): string {
  const requiredFields: (keyof TwitterConfig)[] = [
    'apiKey',
    'apiSecret',
    'accessToken',
    'accessTokenSecret'
  ];

  const missingFields = requiredFields.filter(field => !twitterConfig[field]);

  if (missingFields.length > 0) {
    return `Missing Twitter API credentials: ${missingFields.join(', ')}. Please check your environment variables.`;
  }

  return '';
}

// Get base API URL based on environment
export const getApiBaseUrl = () => {
  return import.meta.env.DEV 
    ? 'http://localhost:3000/api/twitter'
    : '/api/twitter';
};