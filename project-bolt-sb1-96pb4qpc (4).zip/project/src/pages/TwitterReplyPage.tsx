import React, { useState } from 'react';
import TwitterReplyManager from '../components/TwitterReplyManager';
import TwitterFeed from '../components/TwitterFeed';

const TwitterReplyPage: React.FC = () => {
  const [view, setView] = useState<'manager' | 'feed'>('manager');

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setView('manager')}
            className={`px-4 py-2 rounded-md ${
              view === 'manager'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            Reply Manager
          </button>
          <button
            onClick={() => setView('feed')}
            className={`px-4 py-2 rounded-md ${
              view === 'feed'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            Twitter Feed
          </button>
        </div>

        {view === 'manager' ? <TwitterReplyManager /> : <TwitterFeed />}
      </div>
    </div>
  );
};

export default TwitterReplyPage;