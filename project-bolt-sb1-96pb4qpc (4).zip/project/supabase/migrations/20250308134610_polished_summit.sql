/*
  # Initial Schema Setup for ThreadAI

  1. New Tables
    - `replies`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `text` (text)
      - `in_reply_to` (text)
      - `tags` (text[])
      - `created_at` (timestamptz)
      - `ai_metadata` (jsonb)
    
    - `tweets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `reply_id` (uuid, references replies)
      - `text` (text)
      - `scheduled_for` (timestamptz)
      - `created_at` (timestamptz)
      - `status` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to:
      - Read their own data
      - Create new records
      - Update their own records
      - Delete their own records
*/

-- Create replies table
CREATE TABLE IF NOT EXISTS replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  text text NOT NULL,
  in_reply_to text NOT NULL,
  tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  ai_metadata jsonb DEFAULT NULL
);

-- Create tweets table
CREATE TABLE IF NOT EXISTS tweets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  reply_id uuid REFERENCES replies(id) ON DELETE SET NULL,
  text text NOT NULL,
  scheduled_for timestamptz DEFAULT NULL,
  created_at timestamptz DEFAULT now(),
  status text DEFAULT 'pending'
);

-- Enable Row Level Security
ALTER TABLE replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE tweets ENABLE ROW LEVEL SECURITY;

-- Policies for replies table
CREATE POLICY "Users can read own replies"
  ON replies
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create replies"
  ON replies
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own replies"
  ON replies
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own replies"
  ON replies
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for tweets table
CREATE POLICY "Users can read own tweets"
  ON tweets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tweets"
  ON tweets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tweets"
  ON tweets
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own tweets"
  ON tweets
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS replies_user_id_idx ON replies(user_id);
CREATE INDEX IF NOT EXISTS replies_created_at_idx ON replies(created_at);
CREATE INDEX IF NOT EXISTS tweets_user_id_idx ON tweets(user_id);
CREATE INDEX IF NOT EXISTS tweets_scheduled_for_idx ON tweets(scheduled_for);
CREATE INDEX IF NOT EXISTS tweets_status_idx ON tweets(status);