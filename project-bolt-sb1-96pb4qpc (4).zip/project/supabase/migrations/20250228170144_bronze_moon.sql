/*
  # Add AI features to Reply Optimizer

  1. New Tables
    - `drafts` - For storing auto-saved drafts
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `content` (jsonb)
      - `updated_at` (timestamptz)
    
    - `ai_suggestions` - For storing AI-generated reply suggestions
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `original_text` (text)
      - `suggested_text` (text)
      - `platform` (text)
      - `tone` (text)
      - `metrics` (jsonb)
      - `created_at` (timestamptz)
    
    - `auto_saved_replies` - For automatically saved replies from social platforms
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `text` (text)
      - `source` (text)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users to manage their own data
*/

-- Create drafts table for auto-saved content
CREATE TABLE IF NOT EXISTS drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create AI suggestions table
CREATE TABLE IF NOT EXISTS ai_suggestions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  original_text TEXT NOT NULL,
  suggested_text TEXT NOT NULL,
  platform TEXT NOT NULL,
  tone TEXT,
  metrics JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create auto-saved replies table
CREATE TABLE IF NOT EXISTS auto_saved_replies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE drafts ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_suggestions ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_saved_replies ENABLE ROW LEVEL SECURITY;

-- Create policies for drafts
CREATE POLICY "Users can create their own drafts"
  ON drafts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own drafts"
  ON drafts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own drafts"
  ON drafts
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own drafts"
  ON drafts
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for AI suggestions
CREATE POLICY "Users can create their own AI suggestions"
  ON ai_suggestions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own AI suggestions"
  ON ai_suggestions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own AI suggestions"
  ON ai_suggestions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for auto-saved replies
CREATE POLICY "Users can create their own auto-saved replies"
  ON auto_saved_replies
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own auto-saved replies"
  ON auto_saved_replies
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own auto-saved replies"
  ON auto_saved_replies
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS drafts_user_id_idx ON drafts(user_id);
CREATE INDEX IF NOT EXISTS ai_suggestions_user_id_idx ON ai_suggestions(user_id);
CREATE INDEX IF NOT EXISTS auto_saved_replies_user_id_idx ON auto_saved_replies(user_id);