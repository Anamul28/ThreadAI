/*
  # Initial schema for Reply Optimizer

  1. New Tables
    - `replies`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `text` (text)
      - `in_reply_to` (text)
      - `tags` (text array)
      - `created_at` (timestamp)
    - `tweets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `reply_id` (uuid, foreign key to replies)
      - `text` (text)
      - `scheduled_for` (timestamp)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data
*/

-- Create replies table
CREATE TABLE IF NOT EXISTS replies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  in_reply_to TEXT NOT NULL,
  tags TEXT[] DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create tweets table
CREATE TABLE IF NOT EXISTS tweets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reply_id UUID REFERENCES replies(id) ON DELETE SET NULL,
  text TEXT NOT NULL,
  scheduled_for TIMESTAMPTZ DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE tweets ENABLE ROW LEVEL SECURITY;

-- Create policies for replies
CREATE POLICY "Users can create their own replies"
  ON replies
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own replies"
  ON replies
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own replies"
  ON replies
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own replies"
  ON replies
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for tweets
CREATE POLICY "Users can create their own tweets"
  ON tweets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own tweets"
  ON tweets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own tweets"
  ON tweets
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own tweets"
  ON tweets
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS replies_user_id_idx ON replies(user_id);
CREATE INDEX IF NOT EXISTS tweets_user_id_idx ON tweets(user_id);
CREATE INDEX IF NOT EXISTS tweets_scheduled_for_idx ON tweets(scheduled_for);