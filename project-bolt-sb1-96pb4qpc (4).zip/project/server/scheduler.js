import cron from 'node-cron';
import { TwitterApi } from 'twitter-api-v2';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

// Initialize Supabase client
const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Initialize Twitter client
const twitter = new TwitterApi({
  appKey: process.env.VITE_TWITTER_API_KEY,
  appSecret: process.env.VITE_TWITTER_API_SECRET,
  accessToken: process.env.VITE_TWITTER_ACCESS_TOKEN,
  accessSecret: process.env.VITE_TWITTER_ACCESS_TOKEN_SECRET,
});

// Check for tweets to post every minute
cron.schedule('* * * * *', async () => {
  try {
    // Get tweets that are scheduled for now or in the past
    const { data: tweets, error } = await supabase
      .from('tweets')
      .select('*')
      .lte('scheduled_for', new Date().toISOString())
      .eq('status', 'scheduled');

    if (error) throw error;

    // Process each tweet
    for (const tweet of tweets) {
      try {
        // Post to Twitter
        const response = await twitter.v2.tweet(tweet.text);

        // Update tweet status in database
        await supabase
          .from('tweets')
          .update({ 
            status: 'posted',
            posted_at: new Date().toISOString(),
            twitter_tweet_id: response.data.id
          })
          .eq('id', tweet.id);

        console.log(`Successfully posted tweet ${tweet.id}`);
      } catch (tweetError) {
        console.error(`Failed to post tweet ${tweet.id}:`, tweetError);
        
        // Update tweet status to failed
        await supabase
          .from('tweets')
          .update({ 
            status: 'failed',
            error_message: tweetError.message
          })
          .eq('id', tweet.id);
      }
    }
  } catch (error) {
    console.error('Tweet scheduler error:', error);
  }
});

// Retry failed tweets every hour
cron.schedule('0 * * * *', async () => {
  try {
    // Get failed tweets from the last 24 hours
    const { data: failedTweets, error } = await supabase
      .from('tweets')
      .select('*')
      .eq('status', 'failed')
      .gte('scheduled_for', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

    if (error) throw error;

    for (const tweet of failedTweets) {
      try {
        const response = await twitter.v2.tweet(tweet.text);
        
        await supabase
          .from('tweets')
          .update({ 
            status: 'posted',
            posted_at: new Date().toISOString(),
            twitter_tweet_id: response.data.id,
            error_message: null
          })
          .eq('id', tweet.id);

        console.log(`Successfully retried failed tweet ${tweet.id}`);
      } catch (retryError) {
        console.error(`Failed to retry tweet ${tweet.id}:`, retryError);
      }
    }
  } catch (error) {
    console.error('Failed tweet retry error:', error);
  }
});