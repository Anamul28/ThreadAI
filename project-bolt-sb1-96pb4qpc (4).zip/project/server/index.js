import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import { TwitterApi } from 'twitter-api-v2';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? process.env.FRONTEND_URL 
    : 'http://localhost:5173'
}));
app.use(express.json());

// Configure trust proxy if behind a reverse proxy
app.set('trust proxy', 1);

// Rate limiting configuration with proper IP extraction
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  // Custom key generator that safely handles IP extraction
  keyGenerator: (req) => {
    return req.ip || 
           req.headers['x-forwarded-for'] || 
           req.socket.remoteAddress ||
           'unknown-ip';
  }
});

// Apply rate limiting to all routes
app.use(limiter);

// Twitter client initialization with validation
function initializeTwitterClient() {
  const requiredEnvVars = [
    'VITE_TWITTER_API_KEY',
    'VITE_TWITTER_API_SECRET',
    'VITE_TWITTER_ACCESS_TOKEN',
    'VITE_TWITTER_ACCESS_TOKEN_SECRET'
  ];

  const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    console.error('Missing required Twitter environment variables:', missingVars);
    return null;
  }

  try {
    return new TwitterApi({
      appKey: process.env.VITE_TWITTER_API_KEY,
      appSecret: process.env.VITE_TWITTER_API_SECRET,
      accessToken: process.env.VITE_TWITTER_ACCESS_TOKEN,
      accessSecret: process.env.VITE_TWITTER_ACCESS_TOKEN_SECRET,
    });
  } catch (error) {
    console.error('Failed to initialize Twitter client:', error);
    return null;
  }
}

const twitterClient = initializeTwitterClient();

// Health check endpoint
app.get('/api/twitter/health', (req, res) => {
  if (!twitterClient) {
    return res.status(503).json({ 
      status: 'error', 
      message: 'Twitter client not initialized. Please check your environment variables.' 
    });
  }
  res.json({ status: 'ok' });
});

// Twitter API endpoints
app.get('/api/twitter/timeline', async (req, res) => {
  try {
    if (!twitterClient) throw new Error('Twitter client not initialized');
    
    const tweets = await twitterClient.v2.homeTimeline({
      max_results: req.query.count || 20,
      expansions: ['author_id'],
      'tweet.fields': ['created_at', 'public_metrics'],
      'user.fields': ['profile_image_url']
    });
    res.json(tweets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/twitter/mentions', async (req, res) => {
  try {
    if (!twitterClient) throw new Error('Twitter client not initialized');
    
    const mentions = await twitterClient.v2.userMentionTimeline(req.query.userId, {
      max_results: req.query.count || 20,
      expansions: ['author_id'],
      'tweet.fields': ['created_at'],
      'user.fields': ['profile_image_url']
    });
    res.json(mentions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/twitter/reply', async (req, res) => {
  try {
    if (!twitterClient) throw new Error('Twitter client not initialized');
    
    const { tweetId, text } = req.body;
    const reply = await twitterClient.v2.reply(text, tweetId);
    res.json(reply);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/twitter/thread/:tweetId', async (req, res) => {
  try {
    if (!twitterClient) throw new Error('Twitter client not initialized');
    
    const thread = await twitterClient.v2.singleTweet(req.params.tweetId, {
      expansions: ['author_id', 'referenced_tweets.id'],
      'tweet.fields': ['created_at', 'conversation_id'],
      'user.fields': ['profile_image_url']
    });
    res.json(thread);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/twitter/search', async (req, res) => {
  try {
    if (!twitterClient) throw new Error('Twitter client not initialized');
    
    const { query, count } = req.body;
    const tweets = await twitterClient.v2.search(query, {
      max_results: count || 20,
      expansions: ['author_id'],
      'tweet.fields': ['created_at'],
      'user.fields': ['profile_image_url']
    });
    res.json(tweets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  if (!twitterClient) {
    console.log('Warning: Twitter client not initialized. Check your environment variables.');
  }
});