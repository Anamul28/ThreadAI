import React, { useState, useEffect } from 'react';
import { Clock, AlertCircle, Check, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AutoSavedReply {
  id: string;
  text: string;
  source: string;
  created_at: string;
}

const AutoSaveQueue: React.FC = () => {
  const [autoSavedReplies, setAutoSavedReplies] = useState<AutoSavedReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // This would fetch auto-saved replies from the database
    // For demo purposes, we'll use mock data
    const fetchAutoSavedReplies = async () => {
      setLoading(true);
      try {
        // In a real implementation, this would be a Supabase query
        // const { data, error } = await supabase
        //   .from('auto_saved_replies')
        //   .select('*')
        //   .order('created_at', { ascending: false });
        
        // if (error) throw error;
        
        // Mock data for demonstration
        const mockData: AutoSavedReply[] = [
          {
            id: '1',
            text: "Thank you for sharing this insightful article. The points about AI ethics are particularly relevant in today's rapidly evolving tech landscape.",
            source: "https://twitter.com/techjournal/status/1234567890",
            created_at: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
          },
          {
            id: '2',
            text: "I've been using this approach in my projects for years. It's great to see it getting the recognition it deserves. Would love to collaborate on implementing this at scale.",
            source: "https://twitter.com/devexpert/status/9876543210",
            created_at: new Date(Date.now() - 7200000).toISOString() // 2 hours ago
          },
          {
            id: '3',
            text: "This is a fascinating perspective on sustainable development. I particularly appreciate the emphasis on community involvement and long-term planning.",
            source: "https://twitter.com/sustainablefuture/status/5678901234",
            created_at: new Date(Date.now() - 86400000).toISOString() // 1 day ago
          }
        ];
        
        setAutoSavedReplies(mockData);
      } catch (err: any) {
        setError(err.message || 'Failed to load auto-saved replies');
      } finally {
        setLoading(false);
      }
    };

    fetchAutoSavedReplies();
  }, []);

  const handleDismiss = (id: string) => {
    setAutoSavedReplies(prev => prev.filter(reply => reply.id !== id));
  };

  const handleSave = (reply: AutoSavedReply) => {
    // In a real implementation, this would save to your replies collection
    console.log('Saving reply to collection:', reply);
    handleDismiss(reply.id);
    // Show success message or notification
  };

  if (loading) {
    return (
      <div className="border border-gray-200 rounded-xl p-5 bg-white">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-blue-500" />
          Auto-Saved Replies
        </h3>
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="border border-gray-200 rounded-xl p-5 bg-white">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-blue-500" />
          Auto-Saved Replies
        </h3>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
          <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  if (autoSavedReplies.length === 0) {
    return (
      <div className="border border-gray-200 rounded-xl p-5 bg-white">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-blue-500" />
          Auto-Saved Replies
        </h3>
        <p className="text-gray-500 text-center py-6">No auto-saved replies found.</p>
      </div>
    );
  }

  return (
    <div className="border border-gray-200 rounded-xl p-5 bg-white">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
        <Clock className="h-5 w-5 mr-2 text-blue-500" />
        Auto-Saved Replies
      </h3>
      <p className="text-sm text-gray-600 mb-4">
        We automatically save your longer, thoughtful replies so you can reuse them later.
      </p>
      
      <div className="space-y-4">
        {autoSavedReplies.map(reply => (
          <div key={reply.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
            <p className="text-sm text-gray-800 mb-2">{reply.text}</p>
            <div className="flex justify-between items-center">
              <div className="text-xs text-gray-500">
                From: <a href={reply.source} className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">{reply.source.substring(0, 30)}...</a>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleDismiss(reply.id)}
                  className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                  title="Dismiss"
                >
                  <X className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => handleSave(reply)}
                  className="inline-flex items-center px-3 py-1 text-xs font-medium rounded-lg text-green-700 bg-green-50 hover:bg-green-100 transition-colors"
                >
                  <Check className="h-3.5 w-3.5 mr-1.5" />
                  Save to Collection
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AutoSaveQueue;