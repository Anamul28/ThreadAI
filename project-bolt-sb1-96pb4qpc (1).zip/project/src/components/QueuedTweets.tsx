import React, { useContext, useState } from 'react';
import { Calendar, Clock, Trash2, Send, ArrowUp, ArrowDown, CalendarClock } from 'lucide-react';
import { ReplyContext } from '../context/ReplyContext';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import { format } from 'date-fns';

const QueuedTweets = () => {
  const { queuedTweets, removeFromQueue, reorderQueue, scheduleTweet } = useContext(ReplyContext);
  const [showScheduler, setShowScheduler] = useState(false);
  const [scheduledDate, setScheduledDate] = useState<Date | null>(new Date());
  const [tweetToSchedule, setTweetToSchedule] = useState<string | null>(null);

  const handleScheduleTweet = (tweetId: string) => {
    setTweetToSchedule(tweetId);
    setShowScheduler(true);
  };

  const confirmSchedule = () => {
    if (tweetToSchedule && scheduledDate) {
      scheduleTweet(tweetToSchedule, scheduledDate.toISOString());
      setShowScheduler(false);
      setTweetToSchedule(null);
    }
  };

  const moveUp = (index: number) => {
    if (index > 0) {
      reorderQueue(index, index - 1);
    }
  };

  const moveDown = (index: number) => {
    if (index < queuedTweets.length - 1) {
      reorderQueue(index, index + 1);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xl p-8 sticky top-20 transform transition-all hover:scale-[1.01]">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Tweet Queue</h2>
        <span className="bg-blue-100 text-blue-800 text-xs font-medium px-3 py-1 rounded-full">
          {queuedTweets.length} {queuedTweets.length === 1 ? 'Tweet' : 'Tweets'}
        </span>
      </div>

      {queuedTweets.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Your tweet queue is empty</p>
          <p className="text-gray-400 mt-2">Add replies to your queue to post them later as tweets</p>
        </div>
      ) : (
        <div className="space-y-5">
          {queuedTweets.map((tweet, index) => (
            <div key={tweet.id} className="border border-gray-200 rounded-xl p-4 hover:border-blue-300 transition-colors">
              <p className="text-gray-800 text-sm whitespace-pre-wrap mb-3">{tweet.text}</p>
              
              {tweet.scheduledFor && (
                <div className="mb-2 text-xs flex items-center text-gray-500">
                  <CalendarClock className="h-3.5 w-3.5 mr-1.5" />
                  Scheduled for: {format(new Date(tweet.scheduledFor), 'MMM d, yyyy h:mm a')}
                </div>
              )}
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-2">
                  <button 
                    onClick={() => removeFromQueue(tweet.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                    title="Remove from queue"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                  <button 
                    onClick={() => moveUp(index)}
                    className={`p-1.5 ${index > 0 ? 'text-gray-400 hover:text-gray-600' : 'text-gray-200 cursor-not-allowed'} transition-colors`}
                    disabled={index === 0}
                    title="Move up in queue"
                  >
                    <ArrowUp className="h-4 w-4" />
                  </button>
                  <button 
                    onClick={() => moveDown(index)}
                    className={`p-1.5 ${index < queuedTweets.length - 1 ? 'text-gray-400 hover:text-gray-600' : 'text-gray-200 cursor-not-allowed'} transition-colors`}
                    disabled={index === queuedTweets.length - 1}
                    title="Move down in queue"
                  >
                    <ArrowDown className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleScheduleTweet(tweet.id)}
                    className="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-lg text-green-700 bg-green-50 hover:bg-green-100 transition-colors"
                  >
                    <Calendar className="h-3.5 w-3.5 mr-1.5" />
                    Schedule
                  </button>
                  <button className="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition-colors">
                    <Send className="h-3.5 w-3.5 mr-1.5" />
                    Post Now
                  </button>
                </div>
              </div>
            </div>
          ))}

          <div className="mt-8">
            <button className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-sm font-medium rounded-lg shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors">
              <Clock className="h-5 w-5 mr-2" />
              Schedule All Tweets
            </button>
          </div>
        </div>
      )}
      
      {/* Tweet Scheduler Modal */}
      {showScheduler && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Schedule Tweet</h3>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Date and Time
              </label>
              <DatePicker
                selected={scheduledDate}
                onChange={(date) => setScheduledDate(date)}
                showTimeSelect
                timeFormat="HH:mm"
                timeIntervals={15}
                dateFormat="MMMM d, yyyy h:mm aa"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                minDate={new Date()}
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowScheduler(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmSchedule}
                className="px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
              >
                Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QueuedTweets;